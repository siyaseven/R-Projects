"GEE model R code "
rm(list=ls(all=TRUE))
library(geepack)
library(foreign)
options(show.signif.stars=F)
#loading data
#/home/siyabonga/Documents/siyabonga2013_2014files/project
minidata1 <- read.table("~/Documents/siyabonga2013_2014files/project/New_minidata11.csv", header=T,sep=",")
attach(minidata1)
#Normalization of CD4 by taking the square root of CD4 cells
minidata1$CD4.0<- sqrt(CD4.0)
minidata1$CD4.1<- sqrt(CD4.1)
minidata1$CD4.2<- sqrt(CD4.2)
minidata1$CD4.3<- sqrt(CD4.3)
minidata1$CD4.4<-sqrt(CD4.4)
minidata1$CD4.5<- sqrt(CD4.5)
minidata1$CD4.6<-sqrt(CD4.6)
minidata1$CD4.7<- sqrt(CD4.7)
minidata1$CD4.9<- sqrt(CD4.9)
minidata1$CD4.8<- sqrt(CD4.8)
minidata1$CD4.10<- sqrt(CD4.10)
minidata1$ViralBurden <-log(minidata1$ViralBurden)
hist(minidata1$ViralBurden)
attach(minidata1)
#Transforming Data from Wide to Long using Reshape
minidata_long <-reshape(minidata1,idvar=c("PT_NUMBER,age_cont,sex.f,lLogViral5yrs,BMIbin,WHO_stage,"),
                    varying=c("CD4.0","CD4.1","CD4.2","CD4.3","CD4.4","CD4.5","CD4.6",
                            "CD4.7","CD4.8","CD4.9","CD4.10"),direction="long")
minidata_long[1:10,]
#Box plot: part of descriptive analyses
# boxplot(CD4~time*age_cont, data = minidata_long,xlab ="Time(age_cont)",ylab ="Score")
# boxplot(CD4~time*Viral.Burden,data=minidata_long,xlab="Time(Viral.Burden)",ylab="Score")
# boxplot(CD4~time*BMIbin,data=minidata_long,xlab="Time(BMIbin)",ylab="Score")
#boxplot(CD4~time*WHO_stage,data=minidata_long,na.action=na.omit,xlab="Time(WHO_stage)",ylab="Score")
#creating factor variables so to include interaction with time per variable
minidata_long$WHO_stage <- as.factor(minidata_long$WHO_stage)
minidata_long$WHO_stage1 <- (minidata_long$WHO_stage ==1)
minidata_long$WHO_stage2 <- (minidata_long$WHO_stage ==2)
minidata_long$WHO_stage3 <- (minidata_long$WHO_stage ==3)
minidata_long$WHO_stage4 <- (minidata_long$WHO_stage ==4)
minidata_long$comorbs_bin <- as.factor(minidata_long$comorbs_bin)
minidata_long$comorbs_bin0 <- (minidata_long$comorbs_bin ==0)
minidata_long$comorbs_bin1 <- (minidata_long$comorbs_bin ==1)
minidata_long$BMIbin <- as.factor(minidata_long$BMIbin)
minidata_long$BMIbin0 <- (minidata_long$BMIbin ==0)
minidata_long$BMIbin1 <- (minidata_long$BMIbin ==1)
minidata_long$sex.f <- as.factor(minidata_long$sex.f)
minidata_long$sex.f0 <- (minidata_long$sex.f ==0)
minidata_long$sex.f1 <- (minidata_long$sex.f ==1)
minidata_long$VL_supp_cat <- as.factor(minidata_long$VL_supp_cat)
attach(minidata_long)
pairs(~ WHO_stage + comorbs_bin +age_cont+ sex.f, data=minidata1)
minidata_long$time0 <-minidata_long$time - 1
table(time,minidata_long$time0)
M1<-geeglm(CD4~ViralBurden,PT_NUMBER,family=gaussian,corstr="ar1",data=na.omit(minidata_long),id=PT_NUMBER,wave=time)
summary(M1)
M2<-geeglm(CD4~age_cont*time0+sex.f+comorbs_bin+BMIbin,PT_NUMBER,family=gaussian,corstr="ar1",data=na.omit(minidata_long),id=PT_NUMBER,wave=time)
summary(M2)
M3 <- geeglm(CD4~age_cont+sex.f+time0+BMIbin+VL_supp_cat+ViralBurden+WHO_stage+comorbs_bin,PT_NUMBER,family=gaussian,corstr="ar1",
             data=na.omit(minidata_long),id=PT_NUMBER,wave=time)
summary(M3)
M2 <- geeglm(CD4~age_cont+sex.f+time0+VL_supp_cat+ViralBurden+WHO_stage+comorbs_bin,PT_NUMBER,family=gaussian,corstr="ar1",
             data=na.omit(minidata_long),id=PT_NUMBER,wave=time)
summary(M2)

extractAIC(M3)
#confident intervals
coeff<-M3$coefficients  #defines coefficients
coeff
se<-summary(M3)$coefficients["Std.err"] #std error on coefficients
se
attributes(M3)
M3$coefficients
###to get CI's. (confint doesn't work here).  
CIsexf<-coef(M3)["sex.f1"]+c(-1,1)*se["sex.f",]*1.96
CIage_cont<-coef(M3)["age_cont"]+c(-1,1)*se["age_cont",]*1.96
CIInterce<-coef(M3)["Intercept"]+c(-1,1)*se["Intercept",]*1.96
CIBMI<-coef(M3)["BMIbin1"]+c(-1,1)*se["BMIbin1",]*1.96
CIcomorbs<-coef(M3)["comorbs_bin1"]+c(-1,1)*se["comorbs_bin1",]*1.96
CIWHO_stage<-coef(M3)["WHO_stage3 "]+c(-1,1)*se["WHO_stage3 ",]*1.96
CIViralburden<-coef(M3)[" ViralBurden"]+c(-1,1)*se[" ViralBurden",]*1.96
CIVL_supp_cat<-coef(M3)["VL_supp_cat3"]+c(-1,1)*se["VL_supp_cat3",]*1.96
CItimet<-coef(M3)["time0"]+c(-1,1)*se["time0",]*1.96
CItwho<-coef(M3)["ViralBurden"]+c(-1,1)*se["ViralBurden",]*1.96

list(CIViralburden,na.action=na.omit)

CI<-list(CIsexf,CIage_cont,CIBMI,CIcomorbs,CIWHO_stage,CIVL_supp_cat,CIViralburden)

coeff3b<-model3b$coefficients
se3b<-summary(model3b)$coefficients["Std.err"]
CItime2<-coef(model3b)["time0"]+c(-1,1)*se3b["time0",]*1.96

coeff3c<-model3c$coefficients
se3c<-summary(model3c)$coefficients["Std.err"]
CItime3<-coef(model3c)["time0"]+c(-1,1)*se3c["time0",]*1.96

##to display the CI's
CI
attach(minidata_long)
#Model with reference to category and iteration with time
# M4 without interaction

M4 <- geeglm(CD4~age_cont+sex.f+ViralBurden+VL_supp_cat+WHO_stage+comorbs_bin+BMIbin,PT_NUMBER,family=gaussian,corstr="ar1",data=na.omit(minidata_long),id=PT_NUMBER,wave=time)
summary(M4)

#####the following for diagnostics
fitted3<-fitted(M3)
res3<-residuals(M3)

attach(mtcars)
par(mfrow=c(2,2))
plot(fitted3,res3)
plot(M3)
abline(M3, col="red") # regression line (y~x) 
hist(res3)
hist(fitted.values(M3))

attributes(M3)
residuals(M3)
coefficients(M3)
formula(M3)

df.residual(M3)
terms(M3)
anova(M3,M4)
