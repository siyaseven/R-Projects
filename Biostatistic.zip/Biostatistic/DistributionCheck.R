#libraries
library(bindata)
library(geepack)
library(foreign)
library(nlme)
library(lme4)
library(epicalc)
library(MASS)

rm(list=ls(all=TRUE))
#loading data and attaching it

# Setting the right working directory
setwd("~/Downloads")
originaldata <- read.table("Pretoria_data_in_wide_Original.csv",header=T, sep = (","))

# CREATNG SYNTHETIC DATA DISTRIBUTED AS ORIGINAL VARAIBLES


attach(originaldata)
names(originaldata)
codebook(originaldata)

#CD4 RANDOM DATA
cd41.0<-as.integer(abs(rnorm(855,mean=mean(CD4m0,na=T),sd=sd(CD4m0,na=T))))
cd41.1<-as.integer(abs(rnorm(855,mean=mean(CD4m6,na=T),sd=sd(CD4m6,na=T))))
cd41.2<-as.integer(abs(rnorm(855,mean=mean(CD4m12,na=T),sd=sd(CD4m12,na=T))))
cd41.3<-as.integer(abs(rnorm(855,mean=mean(CD4m18,na=T),sd=sd(CD4m18,na=T))))
cd41.4<-as.integer(abs(rnorm(855,mean=mean(CD4m24,na=T),sd=sd(CD4m24,na=T))))
cd41.5<-as.integer(abs(rnorm(855,mean=mean(CD4m30,na=T),sd=sd(CD4m30,na=T))))
cd41.6<-as.integer(abs(rnorm(855,mean=mean(CD4m36,na=T),sd=sd(CD4m36,na=T))))
cd41.7<-as.integer(abs(rnorm(855,mean=mean(CD4m42,na=T),sd=sd(CD4m42,na=T))))
cd41.8<-as.integer(abs(rnorm(855,mean=mean(CD4m48,na=T),sd=sd(CD4m48,na=T))))
cd41.9<-as.integer(abs(rnorm(855,mean=mean(CD4m54,na=T),sd=sd(CD4m54,na=T))))
cd41.10<-as.integer(abs(rnorm(855,mean=mean(CD4m60,na=T),sd=sd(CD4m60,na=T))))

#Creating synthetic data of category data distributed as original data

table(originaldata$sex.f)
table(originaldata$comorbs_bin)
table(originaldata$BMIbin)
ID <- seq(1:855)

SEX <- rmvbin(855,margprob=0.69)
COMORBS <- rmvbin(855,margprob=0.65)
BMIBIN <- rmvbin(855,margprob=0.63)


AGE_CONT <-as.integer(rnorm(855,mean=mean(originaldata$age_cont,na=T),sd=sd(originaldata$age_cont,na=T)))
VIRALBURDEN1 <- as.integer(abs(rnorm(855, mean= 88260.67,sd = 398283.57)))
VIRALBURDEN2 <- as.integer(runif(855, min=50, max=3800000))
min(VIRALBURDEN1)

#for WHO_stage and Viral suppression
#set.seed(124)
schtyp <- sample(1:4, 820, replace = T)
hist(schtyp)

mean(as.integer(runif(854, min=1, max=5)))#=3.101
mean(as.integer(runif(854, min=0, max=4)))#=1.101

WHO_STAGE <- as.integer(runif(855, min=1, max=5))
VL_SUPRESSION_CAT <- as.integer(runif(855, min=0, max=4))


Syntheticdata <- data.frame(ID,AGE_CONT,SEX,COMORBS,WHO_STAGE,BMIBIN,VL_SUPRESSION_CAT,VIRALBURDEN1,cd41.0,cd41.1,cd41.2,cd41.3,cd41.4,cd41.5,cd41.6,cd41.7,cd41.8,cd41.9,cd41.10)

Syntheticdata[1:10,]
#======================================================================
hist(WHO_STAGE)
hist(WHO_stage)

hist(SEX)
hist(sex.f)

hist(BMIBIN)
hist(BMIbin)

hist(VL_SUPRESSION_CAT)
hist(VL_supp_cat)

hist(COMORBS)
hist(comorbs_bin)

hist(sqrt(cd41.0))
hist(sqrt(CD4m0))

hist(sqrt(cd41.1))
hist(sqrt(CD4m6))

hist(sqrt(cd41.2))
hist(sqrt(CD4m12))

hist(sqrt(cd41.3))
hist(sqrt(CD4m18))

hist(sqrt(cd41.4))
hist(sqrt(CD4m24))

hist(sqrt(cd41.5))
hist(sqrt(CD4m30))

hist(sqrt(cd41.6))
hist(sqrt(CD4m36))

hist(sqrt(cd41.7))
hist(sqrt(CD4m42))

hist(sqrt(cd41.8))
hist(sqrt(CD4m48))

hist(sqrt(cd41.9))
hist(sqrt(CD4m54))

hist(sqrt(cd41.10))
hist(sqrt(CD4m60))

hist(log(ViralBurden))
hist(log(VIRALBURDEN1))
summary(PT_NUMBER)
ID1 <- as.integer(runif(855, min=3, max=2000))
ID2 <- as.integer(abs(rnorm(855, mean= 576,sd = 351)))
sd(PT_NUMBER)

hist(PT_NUMBER)
hist(ID)

