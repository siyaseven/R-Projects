rm(list=ls(all=TRUE))

library(geepack)
library(foreign)
options(show.signif.stars=F)

fissure<-read.table(file.choose(),header=T, sep",")

fissure<-read.table("/Users/User/Documents/Biostats 2013/Data/fissure.csv",header = T,sep=",")
attach(fissure)
fissure

names(fissure)<-c("child","gender","age.1","age.2","age.3","age.4") ##need this format
fissure

fissurelong<-reshape(fissure,idvar=c("child","gender"), varying=c("age.1","age.2","age.3","age.4"),direction="long")
fissurelong

boxplot(age~time*gender,data=fissurelong,xlab="Age(gender)",ylab="Fissure")
attach(fissurelong)
interaction.plot(time,gender,age,fun=mean,ylab="Mean Score" ,xlab="Age") ## time interaction

fissurelong$gender<-as.factor(fissurelong$gender)
fissurelong <- fissurelong[order(gender, child),]
fissurelong$female<-(fissurelong$gender==1)
fissurelong$male<-(fissurelong$gender==2)
fissurelong$time0<-fissurelong$time-1

#attach(fissurelong)  ##"don't worry about variables that are 'masked'". 

#the following works far better than attach and detach
fissurelong[,"group"]
fissure$group

########################################################

fissurelong[1:10,]
fissurelong

age<-subset(fissure,select=age.1:age.4)
cor(age)

model0<-geeglm(age~gender*time0,child,family=gaussian,corstr="independence",data=fissurelong,id=child,wave=time)
summary(model0)

model1<-geeglm(age~gender*time0,child,family=gaussian,corstr="exchangeable",data=fissurelong,id=child,wave=time)
summary(model1)

#################### DIAGNOSTICS

coef<-coefficients(model1)
coef
se<-summary(model1)$coefficients["Std.err"]
se
fitted<-fitted(model1)
res<-residuals(model1)
plot(fitted,res)
hist(res)

###################### CIs

CIgender<-coef(model1)["gender2"]+c(-1,1)*se["gender2",]*1.96
CItime0<-coef(model1)["time0"]+c(-1,1)*se["time0",]*1.96
CIgender2time<-coef(model1)["gender2:time0"]+c(-1,1)*se["gender2:time0",]*1.96

CI<-list(CIgender,CItime0,CIgender2time)
coef
CI

######### The final model 
    
model2<-geeglm(age~gender*time0,child,family=gaussian,corstr="ar1",data=fissurelong,id=child,wave=time)
summary(model2)

rm(list=ls(all=TRUE))
