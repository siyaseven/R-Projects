#Checking all objects removed
objects()
rm(list=ls(all=T))

#Reading in and attaching
library(foreign)
library(epicalc)

Alcsmoke<-read.dta("/Users/francesca/Documents/SACEMA2013/DATA/alcsmoke.dta")
names(Alcsmoke)
sapply(Alcsmoke, data.class)

Alcsmoke$alc=as.factor(Alcsmoke$alc)
Alcsmoke$smoke=as.factor(Alcsmoke$smoke)
Alcsmoke$chd=as.factor(Alcsmoke$chd)

sapply(Alcsmoke, data.class)

attach(Alcsmoke)

#Prelim data exploration
tab1(alc)
tab1(smoke)

tabpct(alc,smoke)

tabpct(smoke[alc==0],chd[alc==0])
tabpct(smoke[alc==1],chd[alc==1])

#Models
alcsmoke.1=glm(chd~alc, family=binomial())
summary(alcsmoke.1)
alcsmoke.2=glm(chd~smoke, family=binomial())
summary(alcsmoke.2)
alcsmoke.3=glm(chd~alc+smoke, family=binomial())
summary(alcsmoke.3)
alcsmoke.4=glm(chd~alc+smoke+alc*smoke, family=binomial()) # with the interaction
summary(alcsmoke.4)

vcov(alcsmoke.4)  #useful !

or=exp(coefficients(alcsmoke.4))
conf=exp(confint(alcsmoke.4)) #exponentiate the coefficients and their CI's to get the ORs.
conf  #to display it. If the CI does not include an OR of 1 then there is an effect
logistic.display(alcsmoke.4)  #only available in epicalc


#PLOTTING
par(mfrow=c(1,2))
fitted4=fitted(alcsmoke.4)  #fitted is simply one's predicted values]
tonumber=as.numeric(alc)
plot(chd,fitted4,salc=tonumber)

lines(chd[alc==0],fitted4[alc==0])
lines(chd[alc==1],fitted4[alc==1]) 
##an extreme example of effect modification. slopes are opposite