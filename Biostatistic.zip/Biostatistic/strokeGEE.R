rm(list=ls(all=TRUE))

library(geepack)
library(foreign)
options(show.signif.stars=F)

stroke<-read.dta(file.choose())

#stroke<-read.table("/Users/User/Documents/Biostats 2013/Data/stroke.csv",header = T,sep=",")

attach(stroke)
stroke
names(stroke)<-c("subject","group","week.1","week.2","week.3","week.4","week.5","week.6","week.7","week.8")
stroke

###############################################
#there is a naming convention on variables in long format, hense the .1, .2 etc 

strokelong<-reshape(stroke,idvar=c("subject","group"), varying=c("week.1","week.2","week.3","week.4","week.5","week.6","week.7","week.8"),direction="long")
strokelong

boxplot(week~time*group,data=strokelong,xlab="Time(group)",ylab="Score")
attach(strokelong)

interaction.plot(time,group,week,fun=mean,ylab="Mean Score" ,xlab="Week")

strokelong$group<-as.factor(strokelong$group) #specify grouping variable as a factor (categorical)
strokelong <- strokelong[order(group, subject),]
strokelong$group1<-(strokelong$group==1)
strokelong$group2<-(strokelong$group==2)
strokelong$group3<-(strokelong$group==3)
strokelong$time0<-strokelong$time-1  #rescale time variable by subtracting 1. 

attach(strokelong)
strokelong[1:10,]

week<-subset(stroke,select=week.1:week.8)
cor(week)  ##for the correation structure the data needs to be in wide
table(time,time0) ##just to display result

model1<-geeglm(week~group*time0,subject,family=gaussian,corstr="independence",data=strokelong,id=subject,wave=time)
summary(model1)

model2<-geeglm(week~group+time0+group*time0,subject,family=gaussian,corstr="exchangeable",data=strokelong,id=subject,wave=time)
summary(model2)

model3<-geeglm(week~group*time0,subject,family=gaussian,corstr="ar1",data=strokelong,id=subject,wave=time)

summary(model3)
fitted3<-fitted(model3)  #####the following for diagnostics
res3<-residuals(model3)
plot(fitted3,res3)
hist(res3)
attributes(model3)

############### Note, no CI's. 

model3a<-geeglm(week~group2+group3+time0+group2*time0+group3*time0,subject,family=gaussian,corstr="ar1",data=strokelong,id=subject)
## above includes the time interaction. You may want to choose which time you want as a reference category
## this enables you to have the machine work out what the betas are for each group, rather than having to work it out manually

summary(model3a)
coef3<-coefficients(model3a)
coef3
se3<-std.err(model3a)

model3b<-geeglm(week~group1*time0+group3*time0,subject,family=gaussian,corstr="ar1",data=strokelong,id=subject)
summary(model3b)

model3c<-geeglm(week~group1*time0+group2*time0,subject,family=gaussian,corstr="ar1",data=strokelong,id=subject)
summary(model3c)

model4<-geeglm(week~group*time0,subject,family=gaussian,corstr="unstructured",data=strokelong,id=subject)
summary(model4)

coeff<-model3$coefficients  #defines coefficients
coeff
se<-summary(model3)$coefficients["Std.err"] #std error on coefficients
se

###to get CI's. (confint doesn't work here).  

CIgroup2<-coef(model3)["group2"]+c(-1,1)*se["group2",]*1.96
CIgroup3<-coef(model3)["group3"]+c(-1,1)*se["group3",]*1.96
CItime1<-coef(model3)["time0"]+c(-1,1)*se["time0",]*1.96
CIgroup2time<-coef(model3)["group2:time0"]+c(-1,1)*se["group2:time0",]*1.96
CIgroup3time<-coef(model3)["group3:time0"]+c(-1,1)*se["group3:time0",]*1.96

coeff3b<-model3b$coefficients
se3b<-summary(model3b)$coefficients["Std.err"]
CItime2<-coef(model3b)["time0"]+c(-1,1)*se3b["time0",]*1.96

coeff3c<-model3c$coefficients
se3c<-summary(model3c)$coefficients["Std.err"]
CItime3<-coef(model3c)["time0"]+c(-1,1)*se3c["time0",]*1.96


##to display the CI's
CI<-list(CIgroup2,CIgroup3,CItime1,CIgroup2time,CIgroup3time,CItime2,CItime3)
coeff
CI

##your final model in GEE
model5<-geeglm(week~group+time0,subject,family=gaussian,corstr="ar1",data=strokelong,id=subject,wave=time)
summary(model5)
anova(model3,model5)