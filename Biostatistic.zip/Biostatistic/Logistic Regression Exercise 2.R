rm(list=ls(all=TRUE))

#Packages etc
library(epicalc)
library(foreign)

#Reading in data
pcancer<-read.dta(file.choose())
#pcancer=read.dta("/Users/francesca/Documents/SACEMA2013/DATA/pcancer.dta")

pcancer[1:10,]
summary(pcancer)
codebook(pcancer)
sapply(pcancer,data.class) # lists attributes over the entire dataset
sapply(pcancer,mean) 

par(mfrow=c(1,2))
boxplot(pcancer$age~pcancer$nodal)
boxplot(pcancer$acid~pcancer$nodal)

table(pcancer$xray,pcancer$nodal)
tabpct(pcancer$xray,pcancer$nodal) # graphical too. far beter
table(pcancer$size,pcancer$nodal)
tabpct(pcancer$size,pcancer$nodal)
table(pcancer$grade,pcancer$nodal)
tabpct(pcancer$grade,pcancer$nodal)

#models
attach(pcancer)
hist(acid) #check for normality
logacid=log(acid)
hist(logacid)
pcancer=data.frame(pcancer,logacid) # include the new variable into the dataset

pcancer.1=glm(nodal~logacid+size+grade+xray,family=binomial) #additive
summary(pcancer.1)  # will give AIC, in this case 61.114
logistic.display(pcancer.1) #also gives AIC, but wald and LR tests
conf=exp(confint(pcancer.1))
conf 

pcancer.2=glm(nodal~logacid+size*grade+xray, family=binomial) #multiplicative, i.e. an interaction term
# summary(glm(nodal~logacid+size*grade+size*xray)) #only gives output no actual name + additional interaction
summary(pcancer.2)
logistic.display(pcancer.2)
conf=exp(confint(pcancer.2))
conf

anova(pcancer.1,pcancer.2,test="Chisq") # compare models

pcancer.3=glm(nodal~logacid*grade+size*grade+xray, family=binomial) #another interaction
summary(pcancer.3)
logistic.display(pcancer.3)
conf=exp(confint(pcancer.3))
conf

anova(pcancer.2,pcancer.3,test="Chisq") # compare models again

#diagnostics
attributes(pcancer.2)  ###very important function ! What results are available
attributes(summary(pcancer.2))

plot(pcancer.2$residuals)
plot(summary(pcancer.2)$deviance.resid)

fit=fitted.values(pcancer.2)
predict=predicted.values(pcancer.2)
predict=predicted.values(pcancer.3)

par(mfrow=c(1,2))

plot(pcancer.2$residuals~fit)  ###this is an INDEX plot
plot(pcancer.3$residuals~fit) 
plot(summary(pcancer.2)$deviance.resid~fit)  ## also an Index plot
plot(summary(pcancer.3)$deviance.resid~fit)

cooksd=cooks.distance(pcancer.3)
plot(cooksd,pcancer.3$residuals)
cooksd
max(cooksd)

dfbeta=dfbeta(pcancer.2)
dfbeta

dfbeta=dfbeta(pcancer.3)
dfbeta

 ?dfbeta  #Display index plots (effect on coefficients of deleting each observation in turn)
#In the dfbeta plot, horizontal lines drawn at 0 and +/- one standard error; in the plot of dfbetas, horizontal lines are drawn and 0 and +/- 1

library(car) #companion to applied regression

dfbetaPlots(pcancer.1)
dfbetaPlots(pcancer.2) 
dfbetaPlots(pcancer.3)
# clearly demonstrates the overall goodness of fit of the model and which individuals have a strong influence

