#Logistic
#Reading in and attaching data

framingham<-read.table("/Users/francesca/Documents/SACEMA2013/DATA/framingham_eg.txt",header = T)

attach(framingham)

#Examining data (all columns for the first ten rows)
framingham[1:10,]
library(epicalc)
chol2reverse<-1-chol2
CHDreverse<-1-CHD
tabpct(chol2reverse,CHDreverse)
# Calculating risk ratio
cs(CHD,chol2)

#Creating the odds ratio object, and examining it

par(mfrow=c(1,1))
oddsratio<-cc(CHD,chol2,design="case-control")
oddsratio
oddsratio<-cc(CHD,chol2)
oddsratio

#Model formulation
#Creating object for logistic regression model 1
logreg1<-glm(CHD~chol2,data=framingham,family=binomial())
summary(logreg1)

#Obtaining confidence intervals for the coefficients from this model
confint(logreg1,parm="chol2")

#Back-Transforming
exp(coef(logreg1)["chol2"])
exp(confint(logreg1,parm="chol2"))

#strat

cc(CHD[age==0],chol2[age==0],design="case-control")

cc(CHD[age==0 & sex==0],chol2[age==0 & sex==0],design="case-control")
cc(CHD[age==0 & sex==1],chol2[age==0 & sex==1],design="case-control")

cc(CHD[age==0 & chol2==0],sex[age==0 & chol2==0],design="case-control")
cc(chol2[age==0],sex[age==0],design="case-control")

mhor(CHD[age==0],chol2[age==0],sex[age==0],design="case-control")

#Calculating the unadjusted odds ratio (crude odds ratio)
#as before, but now for age group 30-49
logreg2<-glm(CHD~chol2,family=binomial(),data=subset(framingham[age==0,]))
summary(logreg2)

exp(coef(logreg2))
exp(confint(logreg2))

#Calculating the adjusted odds ratio for age group 30-49
logreg3<-glm(CHD~chol2+ sex,family=binomial(),data=subset(framingham[age==0,]))
summary(logreg3)
exp(coef(logreg3))
exp(confint(logreg3))

#Testing whether or not age and sex satify the condition for confounders:
#Checking if age is a risk factor for CHD (for unexposed)
cc(CHD[chol2==0],age[chol2==0],design="case-control")

#Checking association between age and exposure
cc(chol2,age,design="case-control")

#Checking if sex is a risk factor for CHD (for unexposed)
cc(CHD[chol2==0],sex[chol2==0],design="case-control")

#Checking association between sex and exposure
cc(chol2,sex,design="case-control")

options(show.signif.stars=F)

#Creating objects for logistic regression models 1 to 5
#Model 1
logreg1<-glm(CHD~chol2,data=framingham,family=binomial())
summary(logreg1)
exp(coef(logreg1)["chol2"])
exp(confint(logreg1,parm="chol2"))

#Model 2
logreg2<-glm(CHD~chol2+age,family=binomial())
summary(logreg2)
exp(coef(logreg2)["chol2"])
exp(confint(logreg2,parm="chol2"))

#Model 3
logreg3<-glm(CHD~chol2+sex,family=binomial())
summary(logreg3)
exp(coef(logreg3)["chol2"])
exp(confint(logreg3,parm="chol2"))

#Model 4
logreg4<-glm(CHD~chol2*age,family=binomial())
summary(logreg4)
exp(coef(logreg4))
exp(confint(logreg4,parm="chol2"))

#Model 5
logreg5<-glm(CHD~chol2*sex,family=binomial())
summary(logreg5)
exp(coef(logreg5))
exp(confint(logreg5,parm="chol2"))


#Multiple categories

#Creating factor variable
chol<-as.factor(chol)
levels(chol)

#Creating object for logistic regression model 2
logreg1<-glm(CHD~chol,family=binomial())

#Inference
summary(logreg1)
logistic.display(logreg1)
vcov(logreg1)

#additional model
logreg2=glm(CHD~chol+age*sex+age*chol,family=binomial())
summary(logreg2)
logistic.display(logreg2)
logreg2
vcov(logreg2)
lrtest(logreg1,logreg2)

#validation
attributes(logreg.2)
attributes(summary(logreg.2))

plot(summary(logreg.2)$deviance.resid)
plot(summary(logreg.2)$deviance.resid~fitted(logreg.2))
plot(summary(logreg.2)$deviance.resid~predict(logreg.2))




