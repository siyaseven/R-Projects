rm(list=ls(all=TRUE))

library(nlme)
options(show.signif.stars=F)
 
controlS=nlmeControl(maxIter=1200,pnlsMaxIter=1200,msMaxIter=1200,niterEM=1200,pnlsTol=1e-6)

fissure<-read.table("/Users/User/Documents/Biostats 2013/Data/fissure.csv",header = T,sep=",")
attach(fissure)
fissure

names(fissure)<-c("child","gender","fissure.1","fissure.2","fissure.3","fissure.4")
fissure

fissurelong<-reshape(fissure,idvar=c("child","gender"), varying=c("fissure.1","fissure.2","fissure.3","fissure.4"),direction="long")
fissurelong

fissurelong$gender<-as.factor(fissurelong$gender)
fissurelong$time0<-fissurelong$time-1
fissuredata<-groupedData(fissure~time0|child,outer=~gender,data=fissurelong)
fissuredata
plot(fissuredata)
plot(fissuredata,outer=T)  ##package nlme knows how to do this

memodel1<-lme(fissure~gender*time0,data=fissuredata,random=~1|child) ##with random covariance 
summary(memodel1)
plot(memodel1) ##plots residuals versus fitted
plot(ACF(memodel1),alpha=0.05) ##plots autocrrelation versus time lag
CI1<-intervals(memodel1)
CI1

memodel2<-update(memodel1,correlation=corAR1(),control=controlS) ##with AR1
summary(memodel2)
anova(memodel1,memodel2)
plot(memodel2)  ###nlme does do ANOVA
qqnorm(memodel2,~resid(.))
CI2<-intervals(memodel2)
CI2

memodel4<-lme(fissure~gender*time0,data=fissuredata,random=~time|child)
summary(memodel4)

anova(memodel4,memodel1)
plot(memodel1)
qqnorm(memodel1,~resid(.))
plot(memodel4)
qqnorm(memodel4,~resid(.))
CI4<-intervals(memodel4)
CI4
memodel1ML<-lme(fissure~gender*time0,data=fissuredata,random=~1|child,method="ML")
memodel5ML<-lme(fissure~gender+time0,data=fissuredata,random=~1|child,method="ML")
anova(memodel1ML,memodel5ML)

library(lme4)
detach("package:epicalc")

memodel1a<-lmer(fissure~gender*time+(1|child),data=fissurelong)
memodel1a

qint<-ranef(memodel1a)$child[["(Intercept)"]]
qres<-residuals(memodel1a)
layout(matrix(c(1,2),nrow=1,ncol=2))
qqnorm(qint,main="Random intercepts")
qqline(qint)
qqnorm(qres,main="Residuals")
qqline(qres)

memodel4a<-lmer(fissure~gender*time+(time|child),data=fissurelong)
memodel4a

detach("package:nlme") ## only if ANOVA doesn't want to run.

anova(memodel1a,memodel4a)
qint<-ranef(memodel4a)$child[["(Intercept)"]]
qtime<-ranef(memodel4a)$child[["time"]]
qres<-residuals(memodel4a)
layout(matrix(c(1,2,3,4),nrow=2,ncol=2))
qqnorm(qint,main="Random Intercepts")
qqline(qint)
qqnorm(qtime,main="Random Slopes")
qqline(qtime)
qqnorm(qres,main="Residuals")
qqline(qres)
hist(qres)

memodel1a<-lmer(fissure~gender*time+(1|child),data=fissurelong,REML="FALSE")
memodel1a
