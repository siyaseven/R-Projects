rm(list=ls(all=TRUE))

library(nlme)
options(show.signif.stars=F)

controlS=nlmeControl(maxIter=1200,pnlsMaxIter=1200,msMaxIter=1200,niterEM=1200,pnlsTol=1e-6)
###if the model doesn't converge, increase the iterations

stroke<-read.table("/Users/User/Documents/Biostats 2013/Data/stroke.csv",header = T,sep=",")
attach(stroke)
stroke

names(stroke)<-c("subject","group","week.1","week.2","week.3","week.4","week.5","week.6","week.7","week.8")
stroke

strokelong<-reshape(stroke,idvar=c("subject","group"), varying=c("week.1","week.2","week.3","week.4","week.5","week.6","week.7","week.8"),direction="long")
strokelong

strokelong$group<-as.factor(strokelong$group)
strokedata<-groupedData(week~time|subject,outer=~group,data=strokelong)
strokedata

plot(strokedata)
plot(strokedata,outer=TRUE,key=FALSE)##to exclude the irritating legend

library(epicalc)
use(strokedata) ## another version of 'attach' to approximate Stata

memodel1<-lme(week~group*time,data=strokedata,random=~1|subject) ##adds random intercept for each subject. Could also randomize slope
summary(memodel1) ##note REML is the default. Also gives correlation matrix and residuals
plot(memodel1)
plot(ACF(memodel1),alpha=0.05)##gives an autocorrelation plot (by one unit apart)   

library(lme4)

memodel1<-lmer(week~group*time+(1|subject),data=strokedata,) ##package specifies slightly differently
summary(memodel1)

memodel1<-glmmPQL(week~group*time,data=strokedata,random=~1|subject, family=gaussian,correlation=corAR1())
##glm implementation 

summary(memodel1)
followup.plot(id=subject,time=time,outcome=fitted(memodel1))

memodel2<-update(memodel1,correlation=corAR1(),control=controlS)  ####here the correlation structure specicified
summary(memodel2)

###rather use lmer to compare by ANOVA glmm's do not give this output
anova(memodel1,memodel2)
plot(memodel2)
qqnorm(memodel2,~resid(.))

memodel4<-lme(week~group*time,data=strokedata,random=~time|subject) ##subject specific random effect
summary(memodel4)

##Diagnostics 
##remember the best model has the smallest AIC

anova(memodel4,memodel1)
layout(matrix(1:4,2,2))
plot(memodel1)
qqnorm(memodel1,~resid(.))
plot(memodel4)
qqnorm(memodel4,~resid(.))

memodel1ML<-lme(week~group*time,data=strokedata,random=~1|subject,method="ML")
memodel5ML<-lme(week~group+time,data=strokedata,random=~1|subject,method="ML")
anova(memodel1ML,memodel5ML)

library(lme4)
detach("package:lme4") ##because of the problems it gives with ANOVA
library(lme4)


memodel1a<-lmer(week~group*time+(1|subject),data=strokedata)
memodel1a

qint<-ranef(memodel1a)$subject[["(Intercept)"]]
qres<-residuals(memodel1a)

layout(matrix(c(1,2),nrow=1,ncol=2))
qqnorm(qint,main="Random intercepts")
qqline(qint)
qqnorm(qres,main="Residuals")
qqline(qres)

memodel4a<-lmer(week~group*time+(time|subject),data=strokedata)
memodel4a

anova(memodel1a,memodel4a)
qint<-ranef(memodel4a)$subject[["(Intercept)"]]
qtime<-ranef(memodel4a)$subject[["time"]]
qres<-residuals(memodel4a)
layout(matrix(c(1,2,3,4),nrow=2,ncol=2))
qqnorm(qint,main="Random Intercepts")
qqline(qint)
qqnorm(qtime,main="Random Slopes")
qqline(qtime)
qqnorm(qres,main="Residuals")
qqline(qres)
hist(qres)

memodel1a<-lmer(week~group*time+(1|subject),data=strokedata,REML="FALSE")

