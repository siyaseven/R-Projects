#GLMER and GLMMPQL R code

library(nlme)
library(lme4)
library(epicalc)
library(MASS)
#library(lmerTest)
#library(coda)
options(show.signif.stars=F)

controlS=nlmeControl(maxIter=20200,pnlsMaxIter=20200,msMaxIter=20200,niterEM=20200,pnlsTol=1e-6)

#setting the working directory
setwd("~/Downloads")

#loading data
minidata1 <- read.table("New_minidata11.csv", header = T, sep = ",")

attach(minidata1)

#normalising normalising CD4 so to assume it follows normal distribution 
minidata1$CD4.0<- sqrt(CD4.0)
minidata1$CD4.1<- sqrt(CD4.1)
minidata1$CD4.2<- sqrt(CD4.2)
minidata1$CD4.3<- sqrt(CD4.3)
minidata1$CD4.4<-sqrt(CD4.4)
minidata1$CD4.5<- sqrt(CD4.5)
minidata1$CD4.6<-sqrt(CD4.6)
minidata1$CD4.7<- sqrt(CD4.7)
minidata1$CD4.9<- sqrt(CD4.9)
minidata1$CD4.8<- sqrt(CD4.8)
minidata1$CD4.10<- sqrt(CD4.10)

minidata1$ViralBurden <-log(minidata1$ViralBurden)
attach(minidata1)


#Transforming Data from Wide to Long using Reshape
minidata_long <-reshape(minidata1,idvar=c("PT_NUMBER,age_cont,sex.f,Viral.Burden,BMIbin,WHO_stage,"),
                        varying=c("CD4.0","CD4.1","CD4.2","CD4.3","CD4.4","CD4.5","CD4.6",
                                  "CD4.7","CD4.8","CD4.9","CD4.10"),direction="long")

minidata_long[1:10,]

#creating factor variables so to include interaction with time per variable
minidata_long$WHO_stage <- as.factor(minidata_long$WHO_stage)
minidata_long$WHO_stage1 <- (minidata_long$WHO_stage ==1)
minidata_long$WHO_stage2 <- (minidata_long$WHO_stage ==2)
minidata_long$WHO_stage3 <- (minidata_long$WHO_stage ==3)
minidata_long$WHO_stage4 <- (minidata_long$WHO_stage ==4)

minidata_long$comorbs_bin <- as.factor(minidata_long$comorbs_bin)
minidata_long$comorbs_bin0 <- (minidata_long$comorbs_bin ==0)
minidata_long$comorbs_bin1 <- (minidata_long$comorbs_bin ==1)

minidata_long$BMIbin <- as.factor(minidata_long$BMIbin)
minidata_long$BMIbin0 <- (minidata_long$BMIbin ==0)
minidata_long$BMIbin1 <- (minidata_long$BMIbin ==1)

minidata_long$sex.f <- as.factor(minidata_long$sex.f)
minidata_long$sex.f0 <- (minidata_long$sex.f ==0)
minidata_long$sex.f1 <- (minidata_long$sex.f ==1)

minidata_long$VL_supp_cat <- as.factor(minidata_long$VL_supp_cat)

attach(minidata_long)
# Grouped data
minidata7<-groupedData(CD4~time|PT_NUMBER,outer=~sex.f+comorbs_bin+BMIbin+WHO_stage+age_cont+VL_supp_cat+ViralBurden,data=minidata_long,order.groups=F)

minidata7[1:10,]
#plot(minidata7,outer=TRUE,key=FALSE)
 
attach(minidata7)
#glmer model working #but it does not care about the correlation structure
GLMER<-glmer(CD4~sex.f+BMIbin+time+age_cont+VL_supp_cat+ViralBurden+WHO_stage+comorbs_bin+(1|PT_NUMBER),
             data=minidata7,family=gaussian,na.action=na.omit,REML=T)
summary(GLMER)
GLMER1<-glmer(CD4~sex.f+time+VL_supp_cat+ViralBurden+WHO_stage+comorbs_bin+(1|PT_NUMBER),
             data=minidata7,family=gaussian,na.action=na.omit,REML=T)
summary(GLMER1)
coef(summary.glmer(GLMER))
#calculating AIC
extractAIC(GLMER1)
#confidence interval for GLMER working!
lower <- coef(summary(GLMER))[,1] + qnorm(.025)*coef(summary(GLMER))[,2]
upper <- coef(summary(GLMER))[,1] + qnorm(.975)*coef(summary(GLMER))[,2]
cbind(coef(summary(GLMER)), lower, upper)

#Model diagnostic
attach(mtcars)
par(mfrow=c(3,2))
plot(GLMER)
hist(residuals(GLMER))
hist(fitted3<-fitted(GLMER))
plot(fitted(GLMER),residuals(GLMER))
qqnorm(ranef(GLMER, drop = T)$PT_NUMBER, pch = 19, las = 1, cex = 1.4)
formula(GLMER)
terms(GLMER)

#generalised linear mixed model via Penalised quasi-likelihood
GLMMPQL <- glmmPQL(CD4~ VL_supp_cat+BMIbin+time+WHO_stage+ViralBurden+age_cont+sex.f+comorbs_bin,
         random =list(~ 1| PT_NUMBER) , family= gaussian,data=minidata7,na.action=na.omit)
summary(GLMMPQL)
GLMMPQL1 <- glmmPQL(CD4~ VL_supp_cat+time+WHO_stage+ViralBurden+age_cont+sex.f+comorbs_bin,
                   random =list(~ 1| PT_NUMBER) , family= gaussian,data=minidata7,na.action=na.omit)
summary(GLMMPQL1)
plot(GLMMPQL)
extractAIC(GLMMPQL)
attributes(GLMMPQL)
attributes(GLMMPQL)
confint.coeff(GLMMPQL)
#Diagnosti plots
attach(mtcars)
par(mfrow=c(3,2))
plot(GLMMPQL)
hist(fitted3<-fitted(GLMMPQL))
hist(residuals(GLMMPQL))
plot(fitted(GLMMPQL),residuals(GLMMPQL))
formula(GLMMPQL)
terms(GLMMPQL)