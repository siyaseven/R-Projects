library(nlme)
library(MASS)
library(epicalc)
aids<-read.table("/Users/francesca/Documents/Sacema//AidsWei.csv",header = T,sep=",")
attach(aids)
aids[1:10,]

aids$month<-as.factor(aids$month)
aids$treat<-as.factor(aids$treatment)
aidsdata<-groupedData(viralpos~month|patient,outer=~treat,data=aids)
aidsdata[1:10,]
tabpct(aids$treatment[aids$month==1],aids$viralpos[aids$month==1],percent="row")
tabpct(aids$treatment[aids$month==2],aids$viralpos[aids$month==2],percent="row")
tabpct(aids$treatment[aids$month==3],aids$viralpos[aids$month==3],percent="row")

barplot(tapply(viralpos,list(treatment,month),mean),beside=T)

memodel1a<-glmmPQL(viralpos~treat+month,random=~1|patient,family=binomial(link=logit),data=aidsdata)
summary(memodel1a)

CI<-intervals(memodel1a)
names(CI)
ORlcl<-exp(CI$fixed[,1])
OR<-exp(CI$fixed[,2])
ORucl<-exp(CI$fixed[,3])
results<-cbind(ORlcl,OR,ORucl)
results
fitted<-fitted(memodel1a)
residuals<-residuals(memodel1a)
plot(fitted,residuals)
predp<-exp(fitted)/(1+exp(fitted))
plot(predp~factor(viralpos))
library(lme4)
memodel1b<-lmer(viralpos~treat+month+(1|patient),family=binomial(link="logit"),data=aidsdata)
summary(memodel1b)

OR<-exp(fixef(memodel1b))
est<-esticon(memodel1b,diag(4))
# Odds ratio and confidence intervals
OR.CI <- exp(cbind(est$Estimate, est$Lower, est$Upper))
OR.CI
rownames(OR.CI) <- names(fixef(memodel1b))
colnames(OR.CI) <- c("OR", "Lower OR", "Upper OR")
OR.CI
