
#Exercise 2

#Reading in data
#Obtaining foreign package
library(foreign)

melanoma<-read.dta("/Users/francesca/Documents/SACEMA2013/DATA/MELANOMA.dta")
#Examining first ten rows of dataset
melanoma[1:10,]

#Attaching
attach(melanoma)

#Creating ocean factor variable 
ocean.f=as.factor(ocean)
levels(ocean.f)

model.glm1=glm(mort~lat,family=gaussian)
summary(model.glm1)

#Fitting additional models

model.glm2=glm(mort~lat+ocean)
summary(model.glm2)

model.glm3=glm(mort~lat+ocean+lat*ocean)
summary(model.glm3)

#Inference:
#Model significance
#Individual significance
confint(model.glm2)
confint(model.glm3)

#Examining each model and comparing
anova(model.glm2)
anova(model.glm3)
anova(model.glm2,model.glm3,test="Chisq")

#Diagnostics
par(mfrow=c(2,2))
plot(model.glm2)
plot(model.glm3)

#Examining observation 27
dfbeta.glm2=dfbeta(model.glm2)
dfbeta.glm2

#Interpretation
fitted.glm2=fitted(model.glm2)
fitted.glm3=fitted(model.glm3)

plot(lat, mort)
lines(lat[melanoma$ocean==0],fitted.glm2[melanoma$ocean==0])
lines(lat[melanoma$ocean==1],fitted.glm2[melanoma$ocean==1])

plot(lat, mort)
lines(lat[melanoma$ocean==0],fitted.glm3[melanoma$ocean==0])
lines(lat[melanoma$ocean==1],fitted.glm3[melanoma$ocean==1])

save.image("melanoma2.RData")
detach(melanoma)
rm(list=ls(ALL=True))








