#Exercise 1

#Reading in data
#Obtaining foreign package
library(foreign)

Infant<-read.dta(file.choose())  # best method !!!

melanoma=read.dta("MELANOMA.dta")
melanoma<-read.dta("/Users/francesca/Documents/SACEMA2013/DATA/MELANOMA.dta")
#Examining first ten rows of dataset
melanoma[1:10,]

#Checking names, dim and object type
names(melanoma)
dim(melanoma)
is.data.frame(melanoma)

attach(melanoma) 
# helps prevent having to reference individual parts of the data frame using the $ function
# so if I want to look at a variable directly I can just type its name.
# however, it gets very confusing if you have 2 or more similarly named data sets 
#and for making changes to variables. ie.e it has disadvantages
#Attaching. Renier is not a fan!

#Checking class of variables
sapply(melanoma,data.class)

#Creating ocean factor variable 
ocean.f=as.factor(ocean)
levels(ocean.f)

#Adding it to the dataset
melanoma=data.frame(melanoma,ocean.f)

#IMPORTANT
#Using codebook, summ and tab1 functions to examine dataset

library(epicalc)
codebook(melanoma)

tab1(ocean.f)

#Examine variables and relationships between variables
hist(mort)

par(mfrow=c(3,1))
plot(mort,pop)
plot(mort,lat)
plot(mort,longit)

par(mfrow=c(1,1))
boxplot(mort~ocean.f)
summ(mort, by=ocean.f)

#table apply

tapply(mort, list(ocean),mean)
tapply(pop, list(ocean),mean)
tapply(longit, list(ocean),mean)
tapply(lat, list(ocean),mean)

cor.test(~mort+pop)
cor.test(~mort+lat)
cor.test(~mort+longit)

#Regress latitude on mort using both lm and glm functions
model.lm1=lm(mort~lat)
summary(model.lm1)

model.glm1=glm(mort~lat,family=gaussian)

summary(model.glm1)

#Find confidence intervals
confint(model.glm1)

#IMPORTANT Residual diagnostics
mglm1_resid<-residuals(model.glm1)
mglm1_rstudent<-rstudent(model.glm1)
mglm1_rstandard<-rstandard(model.glm1)
mglm1_fitted<-fitted(model.glm1)
mglm1_cooksd=cooks.distance(model.glm1)

par(mfrow=c(2,2))
plot(mglm1_fitted,mglm1_rstudent)
plot(mglm1_cooksd,mglm1_rstudent)
plot(lat,mglm1_rstudent)
hist(mglm1_resid)

par(mfrow=c(2,2))
plot(model.glm1)

par(mfrow=c(1,1))
plot(lat,mort)
lines(lat,fitted(model.glm1))

save.image("melanoma1.RData")

# detach(melanoma) #takes the data away from direct referencing, but doesn't close the data
#attach(melanoma)

#Fitting additional models

model.glm2=glm(mort~lat+ocean)
summary(model.glm2)

model.glm3=glm(mort~lat+ocean+lat*ocean)
summary(model.glm3)

#Inference:
#Model significance
#Individual significance
confint(model.glm2)
confint(model.glm3)

#Examining each model and comparing
anova(model.glm2)
anova(model.glm3)
anova(model.glm2,model.glm2)

#Diagnostics
par(mfrow=c(2,2))
plot(model.glm2)
plot(model.glm3)

#Examining observation 27
dfbeta.glm2=dfbeta(model.glm2)
dfbeta.glm2

#Interpretation
fitted.glm2=fitted(model.glm2)
fitted.glm3=fitted(model.glm3)

plot(lat, mort)
lines(lat[melanoma$ocean==0],fitted.glm2[melanoma$ocean==0])
lines(lat[melanoma$ocean==1],fitted.glm2[melanoma$ocean==1])

plot(lat, mort)
lines(lat[melanoma$ocean==0],fitted.glm3[melanoma$ocean==0])
lines(lat[melanoma$ocean==1],fitted.glm3[melanoma$ocean==1])

save.image("melanoma2.RData")
detach(melanoma)
rm(list=ls(ALL=True))

