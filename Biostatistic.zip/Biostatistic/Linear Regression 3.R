#Package
library(foreign)
library(epicalc)

#Reading data in
infant=read.dta(file.choose())
infant

names(infant)

#Checking class and creating factors/new variables where required
sapply(infant,data.class)
sex=infant$SX
sex[infant$SX==2]=0
tab1(sex)
tab1(infant$EB)
ebnew=infant$EB
ebnew[infant$EB==3]=2
tab1(ebnew)

infant=data.frame(infant,ebnew,sex)

infant$sex=as.factor(infant$sex)
infant$ebnew=as.factor(infant$ebnew)
infant$SX=as.factor(infant$SX)
infant$EB=as.factor(infant$EB)

sapply(infant,data.class)
levels(infant$SX)
levels(infant$EB)
levels(infant$ebnew)
levels(infant$sex)
attach(infant)

#Data Exploration
growth=GG-GEW
infant=data.frame(infant,growth)
boxplot(growth~EB)
boxplot(growth~ebnew)
boxplot(growth~sex)

by(infant,infant$sex,mean)

par(mfrow=c(2,2))
plot(growth~BMKC2)
plot(growth~OTHER2)

plot(growth~BMPR2)
plot(growth~OTHPR2)

cor.test(~growth+BMKC2)
cor.test(~growth+OTHER2)
cor.test(~growth+BMPR2)
cor.test(~growth+OTHPR2)

#Models
infant.1=glm(growth~EB)
summary(infant.1)
infant.2=glm(growth~EB+BMKC2+sex)
summary(infant.2)


infant.3=glm(growth~EB+BMKC2+sex+BMPR2)
summary(infant.3)

library(car)
vif(infant.3)
#etc.














