#Getting to know the data
#summarising the data, checking the important variables 
library(epicalc)
library(foreign)
#starting with continious variables first!

#Loading Data
OriginalData <- read.table("/home/siyabonga/Desktop/project/Pretoria_data_in_wide_Original.csv",header = T, sep = ",")
OriginalData
#dimension of the data
dim(OriginalData)
attach(OriginalData)
codebook(OriginalData)

table(WHO_stage)
#the CD4 found from codebook
plot(time,CD4.1)
plot(time,CD4.2)
plot(time,CD4.3)
plot(time,CD4.4)
plot(time,CD4.5)
plot(time,CD4.6)
plot(time,CD4.7)
plot(time,CD4.8)
plot(time,CD4.9)
plot(time,CD4.10)

time




table(side_effects)
table(death)
table(comorbs_bin)
table(suppressedVL)
sapply(OriginalData)# finding what object is the variable

#CD4 summary of patients for 60 months taken after six months!
'baseline';summary(CD4m0); 'sixth month' ;summary(CD4m6);'twelfth month';summary(CD4m12)
'18th month';summary(CD4m18); '24th month' ;summary(CD4m24);'30th month';summary(CD4m30)
'36th month';summary(CD4m36); '42th month' ;summary(CD4m42);'48th month';summary(CD4m48)
'54th month';summary(CD4m54); 'last month' ;summary(CD4m60)
length(time)

#viral load for entire study
'baseline';summary(X); 'sixth month' ;summary(VLm6);'twelfth month';summary(VLm12)
'18th month';summary(VLm18); '24th month' ;summary(VLm24);'30th month';summary(VLm30)
'36th month';summary(VLm36); '42th month' ;summary(VLm42);'48th month';summary(VLm48)
'54th month';summary(VLm54); 'last month' ;summary(VLm60)

#summary for CD4 gained from baseline to 24 months
summary(CD4gain)
summary(pyCD4gain2)# summary of per year CD4 gain for 24 months.

#total of CD4 gain maximumCD4 - minimum CD4
summary(totCD4gain)
# meanCD4 after 2 years until the end of study 
summary(meanCD4after2)
summary(totLOGVLpy6)
summary(BMI)

#Checking the distribution of CD4 gain,totCD4 gain,pyCD4 gain and meanCD4 after 2 years.
hist(CD4gain)
hist(meanCD4after2^2)
hist(totCD4gain)
hist(pyCD4gain2)
hist(meanCD4after2)
hist(totLOGVLpy6)
hist(BMI)

#now summarising category variables data
table(agecat)
table(sex.f)
table(BMIbin)
table(WHO_stage)#????
table(BL_CD4_strata)
table(agecat,BL_CD4_strata)
table(suppressedVL)
table(when_suppress)
table(VL_supp_cat)
table(comorbs_bin,suppressedVL)
table(employed,suppressedVL)
table(change)
table(interrupted)
table(stopped)
table(side_effects)
table(defaulter)
table(Untraceable)
table(Nonadherer)
table(Transferred)