## Example of fitting prevalence data with observation error only.
## Steve Bellan, Meaningful Modeling of Epidemiologic Data 2012
## AIMS, Muizenberg

## Used for the MMF


## First we need to create a system of ODEs.  We could also have used
## discrete time formulations.
library(deSolve)

## This is the model from Lab 1
sir <- function(t,y,parms){
  # The with() function gives access to the named values of parms within the
  # local environment created by the function
  with(c(as.list(y),parms),{
    beta <- gamma*R0
    dSdt <- -beta*S*I/N
    dIdt <- beta*S*I/N - gamma*I
    # Note: Population size is constant, so don't need to specify dRdt
    list(c(dSdt,dIdt))
  })
}


time <- 0                               # set initial time
N0 <- 43                           # total population size
initial.SI <- c(S = 42/43*N0, I = 1) # Initially 10% of the population is susceptible

values <- c(R0 = 5,                # set R0
            gamma = 1/15,            # 1 / infectious period = 1/8 days
            N = N0)                 # population size (constant)

## Run ODE for a year with daily time steps output
time.out <- seq(0,96,by = .1)

## This is how we run ODE's in R (see Lab 1 for futher details)
ts.sir <- data.frame(lsoda(
  y = initial.SI,               # Initial conditions for population
  times = time.out,             # Timepoints for evaluation
  func = sir,                   # Function to evaluate
  parms = values                # Vector of parameters
  ))

## What is the prevalence of disease over time?
###################################################################### 
## Task 1: Replace ?? with the appropriate values to get our prevalence curve.
ts.sir$P <- ts.sir$I / N0
  
## Look at our new data frame
head(ts.sir)

## Plot prevalence
plot(ts.sir$time, ts.sir$P, type="l", col="red")
lines()


