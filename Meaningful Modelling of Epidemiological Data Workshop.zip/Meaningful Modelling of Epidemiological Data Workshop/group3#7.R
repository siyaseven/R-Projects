
#calculating Beta(transmission coefficients)
beta.calc2 <- function(Ro,mu=1/(365.25*90),sigma=1/10,gamma=1/10.5){
  Ro/((sigma/(mu+sigma))*(1/(mu+gamma)))
}
beta.calc2(1.22)

#suseptable 
S.star <- function(beta,N,mu=1/(365.25*90),sigma=1/10,gamma=1/10.5){
  N*((mu+sigma)/beta)*((mu+gamma)/sigma)
}
#Exposed/Latent 
E.star <- function(beta,N,mu=1/(365.25*90),sigma=1/10,gamma=1/10.5){
  mu*(N-S.star(beta,N,mu,sigma,gamma))/(mu+sigma)
}
#Infected
I.star <- function(beta,N,mu=1/(365.25*90),sigma=1/10,gamma=1/10.5){
  (sigma/(mu+gamma))*E.star(beta,N,mu,sigma,gamma)
}
#Recovered individuals
R.star <- function(beta,N,mu=1/(365.25*90),sigma=1/10,gamma=1/10.5){
  (gamma/mu)*I.star(beta,N,mu,sigma,gamma)
}

# N0 =2934000
# city = 5
# N0 = N0/city
#N0 <- c(3432000,2934000)
S.star(beta.calc2(8.75),N0)
I.star(beta.calc2(8.75),N0)
pop <- function(t){
  (exp(-17.845493+0.017036*t))
}
 #pop(0:35)
#N0 = pop(1924:1958)/6

t = 1924:1958
Avera_per_day = beta.calc2(8.75) * S.star(beta.calc2(8.75),N0)*I.star(beta.calc2(8.75),N0)/N0
#y= Avera_per_day*365.25
y <- function(t){
  (365*beta.calc2(8.75) * S.star(beta.calc2(8.75),pop(t))*I.star(beta.calc2(8.75),pop(t))/pop(t))
}

#Ontario
plot(c(Ontario$births),y(t),main = "births vs expected number of cases per capita")
lines(c(Ontario$births),y(t),col='red')
lm(plot(c(Ontario$births),c(Ontario$cp),main = "births vs Observed cases per year"))
plot(c(pop(t)),y(t),main="population vs expected number of cases per year")
lm(pop(t),y(t))#,main="population vs expected number of cases per year")
hist(Ontario$cp,col = "blue")

 f = lm(c(Ontario$births)~c(Ontario$cp))
cd = coef(f)
plot(c(Ontario$births),c(Ontario$cp),main = "births vs Observed cases per year")

summary(Ontario$cp)
summary(Ontario$cp)
