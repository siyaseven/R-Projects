#  #######    Advice on using R   ################
#
#  Most commands are functions with many possible arguments
#  Most are set at default values, but try changing them
#
#  The 'help' in RStudio has a good search facility
#
#  A very concise reference card is here
#  http://cran.r-project.org/doc/contrib/Short-refcard.pdf
#
#  An excellent tutorial site is here
#  http://www.statmethods.net/index.html
#  with a good search facility

class.frame <- read.csv("~/Documents/AIMS/class-data.csv", header=T)
summary(class.frame) # to check variable names, missing data etc
# Note that text variables are read in as 'factors': categorical variables taking values from a list
attach(class.frame)  # so can use names directly


# testing if a proportion 14/18 is evidence against 0.5
barplot(dbinom(0:18,18,0.5),names=0:18,col="red")
sum(dbinom(14:18,  18,  0.5))
prop.test(14,18,p=0.5)

pchisq(0.21,1, lower.tail=FALSE)

# testing  for an association between gender and tongue rolling
prop.test(c(14,22),c(18,31))


# fitting a straight line between handspan and height
# only use observations for which height is greater than 145
use= height>145
plot(height[use],handspan[use], xlim=c(140,190),pch=16,col="red")
#  use lm function to fit a line: y = handspan, x = height
fitted=lm(handspan[use]~height[use]) 
abline(fitted, col="blue")
summary(fitted)
 

# testing if there is a real difference between months 

month=factor(birthmonth,levels=c("January","February","March","April","May","June","July","August","September","October","November","December"), labels=c("Ja","Fe","Ma","Ap","My","Jn","Jl","Au","Se","Oc","No","De"),ordered=TRUE)
barplot(table(month),cex.names=0.9)
t=table(month)
X= sum( (t-50/12)^2/ (50/12))
pchisq(X,11, lower.tail=FALSE)
chisq.test(t)

# Suppose I have an estimate t=3 with standard error 1.7.  
# I wish to test whether it comes from a distribution with mean 0
t=3
s=1.7
z=(t-0)/s
Phi=pnorm(z)
P=2*min(Phi,1-Phi)
P