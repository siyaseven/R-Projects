SNP <- read.csv("~/Downloads/SNP_simple.csv",header=T)
summary(SNP)

load("~/Downloads/bremmelgaard.Rdata")
