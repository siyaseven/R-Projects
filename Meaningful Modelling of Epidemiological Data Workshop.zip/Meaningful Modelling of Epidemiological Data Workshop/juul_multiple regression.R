setwd("~/Downloads/juul.Rdata")
J <- load("~/Downloads/juul.Rdata")
ju <- read.csv("~/Downloads/juul2.csv",header = T)
names(ju)
names(juul)
attach(ju)
#detach(juul)

Newdata <- ju[age>=25,]
names(Newdata)

Regre <- lm(sqrt(Newdata$igf1)~Newdata$age+Newdata$weight+Newdata$height,Newdata)
summary(Regre)

               rm(list = ls())
