
tbl=read.table("sac.indsex.dat",header=T) 
x = 1:length(tbl$cYRI)
# plot results
outpdf <- paste("myplot.out", "pdf", sep='.')
pdf(outpdf,width=6, height=5)
plot(x,tbl$cYRI, type="l", col= "black", lty=1, lwd=1.5,ylim=c(0.0,2),xlab = " ", ylab = "",axes=FALSE)
par(new=TRUE)
plot(x,tbl$cSAN,type="l", lty=1,lwd=1.5, col= "blue",ylim=c(0.0,2),xlab = " ", ylab = " ",axes=FALSE)
#par(new=TRUE)
#plot(tbl$POS,tbl$CEU,type="l", lty=2,lwd=1.5, col= "red",ylim=c(0.0,2),xlab = " ", ylab = "",axes=FALSE)
axis(side=1,labels=TRUE,tick=TRUE);
axis(side=2,labels=c("0.0","0.5","1.0"),at=c(0.0,0.5,1.0),tick=TRUE,las=1);
mtext(side=1, outer=FALSE, line=3, "Position along Genome" );
mtext(side=2, adj=0.2, outer=FALSE, line=3, "Ancestry average");#"ancestry of alleles" );
legend("top",lty=1,y=0.25, bty="n", pch=1,cex=0.8,col=c("black","blue"), legend=c("YRI","SAN"))
dev.off()

