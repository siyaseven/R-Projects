#Loading data
Sdata <- read.csv2("/home/siyabonga/Downloads/smoking-and-pregnancy.csv",header=T)
summary(Sdata)
attach(Sdata)

#1.Birthweight ~ kg, Birthlength~cm, Gestationalage~days, if they
#smoking or not, and consumption of cigarates per day.

plot(Smoking,Birthweight,main="Birthweight against smoking",xlab="smoking",
     ylab="Birthweight")
#yes, the average(median) weight of non-smokers children is greater the
#one of smokers children. The interquartile range of non-smokers 
#weight is better than the one smokers children.

#calculting mean of birthweight per smoking category
# mu1 <- mean(Birthweight[Smoking=='Y'])
# mu2 <- mean(Birthweight[Smoking=="N"])
# SD1 <- sd(Birthweight[Smoking=='Y'])
# SD2 <- sd(Birthweight[Smoking=='N'])
# N1 <- length(Birthweight[Smoking=='Y'])
# N2 <- length(Birthweight[Smoking=='N'])
t.test(Birthweight[Smoking=='N'])
t.test(Birthweight~Smoking)

hist(Birthlength)
hist(Birthweight)
hist(GestationalAge)

library(ISwR)
data(intake)
intake
hist(intake$pre)

cbind(intake$pre, rank(intake$pre))
wilcox.test(intake$pre,mu=6000)
wilcox.test(intake$pre,intake$post,paired = T)
