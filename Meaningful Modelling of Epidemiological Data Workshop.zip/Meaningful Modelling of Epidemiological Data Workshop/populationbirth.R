 population = c(2527000, 2934000,3432000,3787655, 4597542,6236000)

 years = seq(from=1911,to=1961,by=10)
 
quad = lm(population ~ I(years^2) + years)
 cq = coef(quad)
 t = seq(from=1911,to=1961,by=1)
 pop.quad = cq[1]+(cq[3]*t)+(cq[2]*(t^2))
 
 
 plot(years, population)
 lines(t,pop.quad, col='red')
 
 #now we have the population for each year
 
 load("~/Documents/MMED Clinic/week one/Group3.Rdata")
 births = Ontario[,2]
 pop.sub = pop.quad[t>1923 & t<1959]
 plot(births,pop.sub, col = rainbow(length(births)))