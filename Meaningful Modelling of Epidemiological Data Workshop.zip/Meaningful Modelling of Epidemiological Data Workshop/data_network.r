# Group Project MMF
# 11 June 2013

install.packages('igraph')

#Packages
library(igraph)






#############################################################################################################
#Import data
#############################################################################################################
#The 10 connections
Edgelist10 <- read.csv('/home/siyabonga/Documents/siyabonga2013_2014files/R/R/Contacts10.csv')

#The 3 connections
Edgelist3 <- read.csv('/home/siyabonga/Documents/siyabonga2013_2014files/R/R/Contacts3.csv')

#The other data
data_LS <- read.csv('DATA FOR MMF ANALYSIS 11.06.2013 DATA ID.csv')






##############################################################################################################
# Different Networks
##############################################################################3###############################


# Basic Network with 10 connections
M10 <- as.matrix(Edgelist10)
M10 <- M10[1:381,]
N_b10 <- graph.edgelist(M10, directed = FALSE)

#tkplot(N_b10)

ad10 <- get.adjacency(N_b10)


G <- graph.adjacency(ad10)
G$vertex.size = 50
#tkplot(G)

# Basic Network with 3 connections
M3 <- as.matrix(Edgelist3)
M3 <- M3[,1:2] #Cleaning data
N_b3 <- graph.edgelist(M3, directed = FALSE)
N_b3 <- delete.edges(N_b3,  c(118))
V(N_b3)$label <- c(1:43)

V(N_b3)$label

#tkplot(N_b3)
plot(N_b3, main =c('3 Edge connection:'))
# Different nodes
V(N_b3)
#Different edges
E(N_b3)

#Adjacency matrix
ad <- get.adjacency(N_b3)
ad
G <- graph.adjacency(ad)
#tkplot(G)

# Degrees of the 3 connection network
deg <-  degree(G, mode = c('in'))
deg
max(deg)

hist(deg)




###############################################################################################################
# FUNCTIONS
###############################################################################################################

##############Function to Calculate the density of the network
N3.density <- function(a,n) {
  sum_a <- 0
  for(ii in 1:dim(a)[1]) {
    for(jj in 1:dim(a)[1]){
      if(ii != jj){
        sum_a<- sum_a+a[ii,jj]
      }
    }
    sum_a<- sum_a/(n*(n-1))
  }
  sum_a
}



##############Function to Calculate degree:
degree_c <- function(ad){
  k <- numeric(dim(ad)[1])
  for(i in 1:dim(ad)[1]){
    k[i]<-sum(ad[i,])
  }
  k
}


###############Function to calculate the Centralization of network
N3.centraalization <- function(kj,di,N){
  (N/(N-2))*((max(kj)/(N-1))-di)
}



##############Function to calculate the heterogeneity of a network
N3.heterogeneity <- function(k1){
  sqrt(var(k1))/mean(k1)
}


##########################################################################################################################
# DIFFERENT NETWORKS
##########################################################################################################################



###################### NETWORK 1: Age with 3 connections
V(N_b3)$individual.age <- c(26, 23, 48, 28, 26, 30, 25, 33, 100, 39, 36, 24, 27, 29, 47, 26, 100, 22, 25, 22, 29, 40, 26, 42, 26, 29, 100, 35, 28, 36, 33, 24, 30, 36, 37, 67, 23, 25, 29, 67, 23, 100, 67)
V(N_b3)[individual.age==100]$color <- "grey"
V(N_b3)[individual.age<70]$color <- "red"
V(N_b3)[individual.age<50]$color <- "orange"
V(N_b3)[individual.age<40]$color <- "yellow"
V(N_b3)[individual.age<35]$color <- "green"
V(N_b3)[individual.age<30]$color <- "purple"
V(N_b3)[individual.age<25]$color <- "blue"
plot(N_b3, main =c('Network of 3 connection: (Age)'))


V(N_b10)$individual.age <- c(26, 23, 48, 28, 26, 30, 25, 33, 100, 39, 36, 24, 27, 29, 47, 26, 100, 22, 25, 22, 29, 40, 26, 42, 26, 29, 100, 35, 28, 36, 33, 24, 30, 36, 37, 67, 23, 25, 29, 67, 23, 100, 67)
V(N_b10)[individual.age==100]$color <- "grey"
V(N_b10)[individual.age<70]$color <- "red"
V(N_b10)[individual.age<50]$color <- "orange"
V(N_b10)[individual.age<40]$color <- "yellow"
V(N_b10)[individual.age<35]$color <- "green"
V(N_b10)[individual.age<30]$color <- "purple"
V(N_b10)[individual.age<25]$color <- "blue"
plot(N_b10, main =c('Network of 3 connection: (Age)'))


#Clean color of nodes
V(N_b3)[individual.age<200]$color <- "grey"

#Clean color of nodes
V(N_b10)[individual.age<200]$color <- "grey"



#################### NETWORK 2: Symtomatic with 3 connections
# Symtomatic network
V(N_b3)$individual.symptomatic <- c(1,1,0,0,1,1,0,0,-1,0,0,0,1,0,0,0,-1,1,0,1,1,1,-1,1,1,1,-1,1,0,1,1,0,1,1,1,0,1,0,0,0,1,-1,0)
V(N_b3)[individual.symptomatic==-1]$color <- "green"
V(N_b3)[individual.symptomatic==1]$color <- "red"
V(N_b3)[individual.symptomatic==0]$color <- "white"
tkplot(N_b3)

barplot(degree(N_b3), main = c('Degree of different nodes'), xlab = c('nodes'),
        ylab = c('degree'),
        col = 'red')

hist(degree(N_b3),breaks=c(seq(-0.5,11.5,1)), main = c('Degree distribution:'), xlab = c('Degree( n = 43)'), col = 'red')

# Get the Asymtomatic people and people that was not symtomatic
Asymptomatic <- numeric(20)
Nonsymtomatic <- numeric(24)

c1 <- 1
c2 <- 1
for(i in 1:43){
  if(V(N_b3)$individual.symptomatic[i]<1){
    Nonsymtomatic[c1] <- i
    c1 <- c1 + 1
  }
  if(V(N_b3)$individual.symptomatic[i]==1){
    Asymptomatic[c2] <- i
    c2 <- c2 + 1
  }
}
Nonsymtomatic  
Asymptomatic

# Create the Asymptomatic Network
N_symptomatic <- delete.vertices(N_b3,  Nonsymtomatic)
tkplot(N_symptomatic)

degree(N_symptomatic, mode = c('in'))


deg_3_sym <- mean(degree(N_symptomatic, mode = c('in')))
deg_3_sym <- mean(degree(N_symptomatic))
deg_3_sym

deg_3_sym <- mean(degree(N_symptomatic, mode = c('out')))
deg_3_sym

n_N_symp <- length(Asymptomatic)

ad_N_symp <- get.adjacency(N_symptomatic)

density_N_symptomatic <- N3.density(ad_N_symp, n_N_symp)
degree_N_symptomatic <- degree_c(ad_N_symp)
centralization_N_symptomatic <- N3.centraalization(degree_N_symptomatic, density_N_symptomatic, n_N_symp)
heterogeneity_N_symptomatic <- N3.heterogeneity(degree_N_symptomatic)

density_N_symptomatic
degree_N_symptomatic 
centralization_N_symptomatic 
heterogeneity_N_symptomatic 


#################### NETWORK 2: Symtomatic with 10 connections
# Symtomatic network
V(N_b10)$individual.symptomatic <- c(1,1,0,0,1,1,0,0,-1,0,0,0,1,0,0,-1,-1,1,-1,1,1,1,-1,1,1,1,-1,1,-1,1,1,0,1,1,1,0,1,0,0,0,1,-1,0)
V(N_b10)[individual.symptomatic==-1]$color <- "green"
V(N_b10)[individual.symptomatic==1]$color <- "red"
V(N_b10)[individual.symptomatic==0]$color <- "white"
plot(N_b10, main = c('Symptomic(Red), Nonsymptomic(blue), Nodata(Grey)'))


# Get the Asymtomatic people and people that was not symtomatic
Asymptomatic10 <- numeric(20)
Nonsymtomatic10 <- numeric(24)

c1 <- 1
c2 <- 1
for(i in 1:43){
  if(V(N_b10)$individual.symptomatic[i]<1){
    Nonsymtomatic10[c1] <- i
    c1 <- c1 + 1
  }
  if(V(N_b10)$individual.symptomatic[i]==1){
    Asymptomatic10[c2] <- i
    c2 <- c2 + 1
  }
}
Nonsymtomatic10 
Asymptomatic10

# Create the Asymptomatic Network
N_symptomatic10 <- delete.vertices(N_b10,  Nonsymtomatic10)
tkplot(N_symptomatic10)




deg_10_sym <- mean(degree(N_symptomatic10, mode = c('in')))
deg_10_sym

################# NETWORK 2: Create the Non symptomatic Network
other <- c(9,19,42,17,27,29,23,16)
cuta <- c(Asymptomatic, other)
N_Nsymptomatic <- delete.vertices(N_b3,  cuta)
tkplot(N_Nsymptomatic)

deg_3_Nsym <- mean(degree(N_Nsymptomatic, mode = c('in')))
deg_3_Nsym


n_N_Nsymp <- length(Nonsymtomatic )

ad_N_Nsymp <- get.adjacency(N_Nsymptomatic)

density_N_Nsymptomatic <- N3.density(ad_N_Nsymp, n_N_Nsymp)
degree_N_Nsymptomatic <- degree_c(ad_N_Nsymp)
centralization_N_Nsymptomatic <- N3.centraalization(degree_N_Nsymptomatic, density_N_Nsymptomatic, n_N_Nsymp)
heterogeneity_N_Nsymptomatic <- N3.heterogeneity(degree_N_Nsymptomatic)

density_N_Nsymptomatic 
degree_N_Nsymptomatic 
centralization_N_Nsymptomatic 
heterogeneity_N_Nsymptomatic 

################# NETWORK 2: Create the Non symptomatic Network
other <- c(9,19,42,17,27,29,23,16)
cuta10 <- c(Asymptomatic10, other)
N_Nsymptomatic10 <- delete.vertices(N_b10,  cuta10)
tkplot(N_Nsymptomatic10)


degree(N_Nsymptomatic10, mode = c('in'))
deg_10_Nsym <- mean(degree(N_Nsymptomatic10, mode = c('in')))
deg_10_Nsym


###################### NETWORK 3: African

USAC_AFR <- c(1,1,0,0,0,1,1,0,-1,0,1,1,1,1,0,0,-1,1,1,1,1,1,0,1,0,0,-1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,-1,1)

USAC <- numeric(12)
AFR <- numeric(28)

c1 <- 1
c2 <- 1
for(i in 1:43){
  if(USAC_AFR[i]==0){
    USAC[c1] <- i
    c1 <- c1 + 1
  }
  if(USAC_AFR[i]==1){
    AFR[c2] <- i
    c2 <- c2 + 1
  }
}
USAC  
AFR

other <- c(9,19,42,17,27,29,23,16)
cut <- c(USAC, other)

N_Afr <- delete.vertices(N_b3,  cut)
rglplot(N_Afr)

n_N_Afr <- length(AFR)

ad_N_Afr <- get.adjacency(N_Afr)

density_N_Afr <- N3.density(ad_N_Afr, n_N_Afr)
degree_N_Afr <- degree_c(ad_N_Afr)
centralization_N_Afr <- N3.centraalization(degree_N_Afr, density_N_Afr, n_N_Afr)
heterogeneity_N_Afr <- N3.heterogeneity(degree_N_Afr)

density_N_Afr 
degree_N_Afr 
centralization_N_Afr 
heterogeneity_N_Afr 


################## NETWORK 4: USAC
cut <- c(AFR, other)

N_USAC <- delete.vertices(N_b3,  cut)
plot(N_USAC, main =c('Not African 3 connections'))

n_N_USAC <- length(USAC)

ad_N_USAC <- get.adjacency(N_USAC)

density_N_USAC <- N3.density(ad_N_USAC, n_N_USAC)
degree_N_USAC <- degree_c(ad_N_USAC)
centralization_N_USAC <- N3.centraalization(degree_N_USAC, density_N_USAC, n_N_USAC)
heterogeneity_N_USAC <- N3.heterogeneity(degree_N_USAC)

density_N_USAC 
degree_N_USAC 
centralization_N_USAC 
heterogeneity_N_USAC 


###################### NETWORK 5: FACULTY
faculty1 <-  c(0,0,1,0,0,0,0,1,-1,1,0,0,0,0,1,0,-1,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,0,0,0,0,1,0,0,0,1,0,-1,1)
mentor1 <- c(0,0,0,0,0,1,1,0,-1,0,0,0,0,1,0,0,-1,0,0,0,0,0,0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-1,0)

faculty <- numeric(7)
mentor <- numeric(3)
other1 <- numeric(28)
other2 <- c(4,5,17,40)

c1 <- 1
c2 <- 1
c3 <- 1
for(i in 1:43){
  if(faculty1[i]==1){
    faculty[c1] <- i
    c1 <- c1 + 1
  }
  if(mentor1[i]==1){
    mentor[c2] <- i
    c2 <- c2 + 1
  }
  if(faculty1[i]==0 & mentor1[i]==0){
    other1[c3] <- i
    c3 <- c3 + 1
  }
}
faculty
mentor
other1


other <- c(9,19,42,17,27,29,23,16)
cut1 <- c(mentor, other1, other2)

N_faculty <- delete.vertices(N_b3,  cut1)
plot(N_faculty, main = c('Faculty network 3 connections'))

n_N_faculty <- length(faculty)

ad_N_faculty <- get.adjacency(N_faculty)

density_N_faculty <- N3.density(ad_N_faculty, n_N_faculty)
degree_N_faculty <- degree_c(ad_N_faculty)
centralization_N_faculty <- N3.centraalization(degree_N_faculty, density_N_faculty, n_N_faculty)
heterogeneity_N_facutly <- N3.heterogeneity(degree_N_faculty)

density_N_faculty 
degree_N_faculty 
centralization_N_faculty 
heterogeneity_N_facutly 


###################### NETWORK 5: Mentor

other2 <- c(9,19,42,17,27,29,23,16)
cut2 <- c(faculty, other1, other2)

N_mentor <- delete.vertices(N_b3,  cut2)
plot(N_mentor, main = c('Mentor network 3 connections'))

n_N_mentor <- length(mentor)

ad_N_mentor <- get.adjacency(N_mentor)

density_N_mentor <- N3.density(ad_N_mentor, n_N_mentor)
degree_N_mentor <- degree_c(ad_N_mentor)
centralization_N_mentor <- N3.centraalization(degree_N_mentor, density_N_mentor, n_N_mentor)
heterogeneity_N_mentor <- N3.heterogeneity(degree_N_mentor)

density_N_mentor 
degree_N_mentor 
centralization_N_mentor 
heterogeneity_N_mentor 


###################### NETWORK 5: Other1
cut3 <- c(faculty, mentor, other2)

N_par <- delete.vertices(N_b3,  cut3)
plot(N_par, main =c('ORDINARY PAR network 3 connections'))

n_N_par <- length(par)

ad_N_par <- get.adjacency(N_par)

density_N_par <- N3.density(ad_N_par, n_N_par)
degree_N_par <- degree_c(ad_N_par)
centralization_N_par <- N3.centraalization(degree_N_par, density_N_par, n_N_par)
heterogeneity_N_par <- N3.heterogeneity(degree_N_par)

density_N_par 
degree_N_par 
centralization_N_par 
heterogeneity_N_par 










#Time network:
V(Network_basic10)$individual.symptomatic.time <- c(3.5,
                                                    6,
                                                    -1,
                                                    -1,
                                                    6,
                                                    34,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    12.111111111,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    2,
                                                    -1,
                                                    2.5,
                                                    2.833333,
                                                    28.44444,
                                                    -1,
                                                    27,
                                                    15,
                                                    2,
                                                    -1,
                                                    31,
                                                    -1,
                                                    5.6,
                                                    3,
                                                    -1,
                                                    12,
                                                    26.3333333,
                                                    27.3333333,
                                                    -1,
                                                    28.8333333,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    29,
                                                    -1,
                                                    -1
)

V(Network_basic10)[individual.symptomatic.time<35]$color <- "red"
V(Network_basic10)[individual.symptomatic.time<25]$color <- "orange"
V(Network_basic10)[individual.symptomatic.time<15]$color <- "yellow"
V(Network_basic10)[individual.symptomatic.time<5]$color <- "green"
V(Network_basic10)[individual.symptomatic.time<4]$color <- "purple"
V(Network_basic10)[individual.symptomatic.time<3]$color <- "blue"
V(Network_basic10)[individual.symptomatic.time<1]$color <- "grey"


plot(Network_basic10)
tkplot(Network_basic10)

V(Network_basic3)$individual.symptomatic.time <- c(3.5,
                                                    6,
                                                    -1,
                                                    -1,
                                                    6,
                                                    34,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    12.111111111,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    2,
                                                    -1,
                                                    2.5,
                                                    2.833333,
                                                    28.44444,
                                                    -1,
                                                    27,
                                                    15,
                                                    2,
                                                    -1,
                                                    31,
                                                    -1,
                                                    5.6,
                                                    3,
                                                    -1,
                                                    12,
                                                    26.3333333,
                                                    27.3333333,
                                                    -1,
                                                    28.8333333,
                                                    -1,
                                                    -1,
                                                    -1,
                                                    29
)

V(Network_basic3)[individual.symptomatic.time<35]$color <- "red"
V(Network_basic3)[individual.symptomatic.time<25]$color <- "orange"
V(Network_basic3)[individual.symptomatic.time<5]$color <- "yellow"
V(Network_basic3)[individual.symptomatic.time<4]$color <- "green"
V(Network_basic3)[individual.symptomatic.time<3]$color <- "purple"
V(Network_basic3)[individual.symptomatic.time<2.1]$color <- "blue"
V(Network_basic3)[individual.symptomatic.time<1]$color <- "grey"


#plot(Network_basic10)
tkplot(Network_basic3)

# Age network with 10 connections
V(Network_basic10)$individual.age <- c(26,
                                       23,
                                       48,
                                       28,
                                       26,
                                       30,
                                       25,
                                       33,
                                       100,
                                       39,
                                       36,
                                       24,
                                       27,
                                       29,
                                       47,
                                       26,
                                       100,
                                       22,
                                       25,
                                       22,
                                       29,
                                       40,
                                       26,
                                       42,
                                       26,
                                       29,
                                       100,
                                       35,
                                       28,
                                       36,
                                       33,
                                       24,
                                       30,
                                       36,
                                       37,
                                       67,
                                       23,
                                       25,
                                       29,
                                       67,
                                       23,
                                       100,
                                       67)
V(Network_basic10)[individual.age==100]$color <- "grey"
V(Network_basic10)[individual.age<70]$color <- "red"
V(Network_basic10)[individual.age<50]$color <- "orange"
V(Network_basic10)[individual.age<40]$color <- "yellow"
V(Network_basic10)[individual.age<35]$color <- "green"
V(Network_basic10)[individual.age<30]$color <- "purple"
V(Network_basic10)[individual.age<25]$color <- "blue"
tkplot(Network_basic10)