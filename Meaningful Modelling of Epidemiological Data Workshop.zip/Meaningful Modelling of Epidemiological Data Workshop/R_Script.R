#R provides an environment in which you can perform statistical analysis and produce graphics
# http://www.r-project.org

# To start R, open a terminal and type R
# Type q() to exit from R

#R has too many tools for anyone to remember them all,
#example of help:
?plot
help.search("graphics")
#Several packages come pre-installed with R.
rownames(installed.packages())

#install a package
install.packages("ISwR")

# Import a packages:
library("ISwR")

############# Basic Example ###################

# Simple Examples, type the follows exp, log and runif which are R functions:
exp(-2)
log(100, base = 10)
#Generates 10 random numbers between 0 and 1
runif(10)

## Simple Plotting
plot(runif(10))

#The c(...) construct can be used to create vectors
weight <- c(60, 72, 57, 90, 95, 72)
weight
summary(weight)
#To generate a vector of regularly spaced numbers, use

x = seq(0, 1, length = 11)
y= 1:10

########################### Basic Operation ######################################################
#Common arithmetic operations (including +, -, *, /, ^) and mathematical functions (e.g. sin, cos, log) work element-
#wise on vectors, and produce another vector

height <- c(1.75, 1.8, 1.65, 1.9, 1.74, 1.91)
height^2
bmi <- weight/height^2
bmi
log(bmi)
sum(weight)
plot(x = height, y = weight)
a=2
 c = a^3
show(c)
##many options that can control the details of what the plot looks like
plot(x = height, y = weight, pch = 2, col = "red")
hh <- c(1.65, 1.7, 1.75, 1.8, 1.85, 1.9)
lines(x = hh, y = 22.5 * hh^2)
title(main = "weight vs height, with BMI = 22.5 curve")

###########################  Descriptive Statistics ##################################
#Simple summary statistics: mean, median, standard deviation,variance

x <- rnorm(100)
length(x) 
sum(x) #Sums the elements in x
prod(x) #Product of the elements in x
max(x) #Maximum element in x
min(x) 
mean(x)
sd(x)
var(x)
median(x)
xquants <- quantile(x) #The p quantile of x

cor(x,y) 

cov(x,y) 

########################### Iris Data #################################
#Let’s look at a real example: The Iris data set is one of many already available in R 

#######*****This data set contains measurements on 150 flowers, 50 each from 3 species: Iris setosa, versicolor and #virginica************

x<-iris
names(x) #to see the columns	
# We can have a quick summary of our Data by typying summary(iris)
summary(iris)
#The simplest plot of numeric data is a strip plot(often called a dot plot)
stripchart(x)

# More better
stripchart(iris[, 1:4], method = "stack", pch = 16,cex = 0.4, offset = 0.6)


#################################### Basic on Probability #########################################
#Discrete random variables, the associated probability distributions can be described using a table to “model” the probability as above for the RNA
#analysis

X<-c(0,1,2,3)
Prob<-c(0.208,0.167,0.25,0.375)
N<-c('A', 'C', 'G', 'U')
barplot(Prob,names=N,ylab="Probability", main="RNA Residue Analysis")

### Exercise1: Binomial Distribution ####
#Generate the probability values for the binomial distribution for the number of children in 10 with blue eyes using p
#=0.16 and plot the probability

x<-0:10
y<-dbinom(0:10,10,0.16)
data.frame("Prob"=y,row.names=x)

plot(0:10,dbinom(0:10,10,0.16),type='l',xlab="",ylab="Probability",sub="Number of kids with blue eyes")


This plot will help visualize the probability of getting between 45 and 55 heads in 100 coin tosses.
gbinom(100, 0.5, a = 45, b = 55, scale = T)


#Suppose we have a sample of size n=200 belonging from a
#normal population N(10,2) with mean=10 and standard deviation=2:
x.norm<-rnorm(n=200,m=10,sd=2)
hist(x.norm,main="Histogram of observed data")
#We can estimate frequency density using density()and plot()to plot the graphic
plot(x.norm,type='l',col='red')
#clipplot(lines(x,col='blue'),xlim=c(0,20),ylim=c(4,16))
plot(density(x.norm),main="Density estimate of data")
plot(ecdf(x.norm),main="Empirical cumulative distribution function")
#the empirical cumulative distribution function by ecdf()

#A Quantile-Quantile (Q-Q) plot3 is a scatter plot comparing the fitted and empirical distributions in terms of
#the dimensional values of the variable
z.norm<-(x.norm-mean(x.norm))/sd(x.norm)
qqnorm(z.norm) ## drawing the QQplot
abline(0,1) ## drawing a 45-degree reference line

#If data differ from a normal distribution (i.e. data belonging from a Weibull pdf) we can use qqplot()in
#this way
x.wei<-rweibull(n=200,shape=2.1,scale=1.1) ## sampling from a Weibull

x.teo<-rweibull(n=200,shape=2, scale=1) ## theorical quantiles from a
#Weibull population with known paramters shape=2 e scale=1
qqplot(x.teo,x.wei,main="QQ-plot distr. Weibull") ## QQ-plot
abline(0,1) ## a 45-degree reference line is plotted

#######################Poisson Distribution #####
x.poi<-rpois(n=200,lambda=2.5)
hist(x.poi,main="Poisson distribution")
curve(dnorm(x,m=10,sd=2),from=0,to=20,main="Normal distribution")
curve(dgamma(x, distribution")
library(fBasics)
#To compute skewness and kurtosis index we can use those statements: skewness() and kurtosis()

kurtosis(x.norm)

x.gam<-rgamma(200,rate=0.5,shape=3.5)

##sampling from a gamma
