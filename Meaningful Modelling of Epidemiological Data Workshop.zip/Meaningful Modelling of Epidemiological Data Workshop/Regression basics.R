#data loading 
rdata <- read.csv("/home/siyabonga/Downloads/rmr.csv",header = T)
rdata
attach(rdata)
#.number 1
#plot(metabolic.rate,body.weight,main="metabolic rate against body weight")
plot(body.weight,metabolic.rate)
#number 2. yes it seems reasonable, i think metabolic rate 
#can change much in 24 hrs than body weight
LinearR <- lm(metabolic.rate~body.weight, rdata)
summary(LinearR)
plot((LinearR))
abline(LinearR)
plot(residuals(LinearR))


sd(residuals(LinearR))
detach(rdata)
#=======================================================================
#load Data
#question 2
sleep
