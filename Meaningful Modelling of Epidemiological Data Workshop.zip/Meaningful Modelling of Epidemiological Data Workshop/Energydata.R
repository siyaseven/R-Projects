attach(energy)
#wilcoxin test
boxplot(expend[stature=="obese"],expend[stature=="lean"],
        names=c("Obese","lean"),main="Energy Expenditure for lean & obese",
        ylab ='expenditure' ,xlab="stature")

wilcox.test(expend[stature=="obese"],expend[stature=="lean"])
wilcox.test(log(expend[stature=="obese"]),log(expend[stature=="lean"]))

#T test

t.test(expend[stature=="obese"],expend[stature=="lean"])
t.test(log(expend[stature=="obese"]),log(expend[stature=="lean"]))


summary(1:10,4)

