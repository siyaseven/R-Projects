#  #######    Advice on using R   ################
#
#  Most commands are functions with many possible arguments
#  Most are set at default values, but try changing them
#
#  The 'help' in RStudio has a good search facility
#
#  A very concise reference card is here
#  http://cran.r-project.org/doc/contrib/Short-refcard.pdf
#
#  An excellent tutorial site is here
#  http://www.statmethods.net/index.html
#  with a good search facility

class.frame <- read.csv("~/Documents/AIMS/class-data.csv", header=T)
summary(class.frame) # to check variable names, missing data etc
# Note that text variables are read in as 'factors': categorical variables taking values from a list
attach(class.frame)  # so can use names directly

# do the heights have a normal distribution?
# See website http://www.statmethods.net/graphs/density.html
# for instructions on putting curves on top of histograms
#ht=na.omit(height)  # leave out missing values
#hist(ht,col="red")
#m=mean(ht) # MLEs of mean and variance
v=var(ht)
num_obs=length(ht)
h<-hist(ht, col="red")# saves histogram in object h
binwidth=diff(h$mids[1:2]) # find the width of the 'bins'
xfit<-seq(min(ht),max(ht),length=100) # specify a curve with 100 points between min and max heights
yfit<-dnorm(xfit,mean=m,sd=sqrt(v))   # calculate normal curve
# We now need to rescale normal curve to have same area as histogram
# The histogram comprises num_obs observations, each of width binwidth
# and so has total area binwidth*num_obs
yfit <- yfit*binwidth*num_obs # 
lines(xfit, yfit, col="blue", lwd=2) # draw curve, pwd=2 makes it a thicker line

# Now try fitting 
# a Normal to the breath data
# a Normal to the log of the breath data
# Poisson to the sibling data,
# a geometric to the dice data
o=rnorm(100)
run o






