#!/usr/bin/Rscript --vanilla

###### Loading data of the South African Coloured population from files #####

#Data of 733 unrelated South African Coloured TB cases and controls, age, sex and individual genetic ancestry proportion #from Yoruba (cYRI), Khoesan(cSAN), European (cCEU), East-Asian (cCHB) and Indian (cGIH).
#### The qestion is to investigate the relationship between TB status , gender and genetic ancestry ###
dat2 = read.csv("/home/emile/R_Class/class-data.csv", header=T)
summary(dat2)

gender = dat2$Gender
beans = data2$Beans
hist(beans)
?plot

#ind sample gender diagnosis age
dat2 = read.table("sac.indsex.txt", header=T)
age<-dat2$cAGE
sex<-dat2$cSEX
age
cor(age,sex)
#sex is not significant p-value 0.597
#age is significant p-value 1.52e-05 mean age 37 in affecteds and 31 in controls

#tb<-dat2$cPHENO
#khs<-dat2$cSAN
#ceu<-dat2$cCEU
#chb<-dat2$cCHB
#gih<-dat2$cCHB
#res<-lm(tb~age+sex)
#summary(res)
#print("Correction of TB and Yoruba")
#res.yri<-lm(tb~yri)
#summary(res.yri)
##print("Correction of TB and Khoesan")
#res.khs<-lm(tb~khs)
#summary(res.khs)
#print("Correction of TB and European")
#res.ceu<-lm(tb~ceu)
#summary(res.ceu)
#print("Correction of TB and Indian")
##res.gih<-lm(tb~gih)
#summary(res.gih)
#print("Correction of TB and Eas-Asian")
#res.chb<-lm(tb~chb)
#summary(res.chb)
