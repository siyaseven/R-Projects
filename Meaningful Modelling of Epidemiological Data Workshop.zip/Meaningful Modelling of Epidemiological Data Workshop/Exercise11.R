rm(list=ls())

Tafel <- as.table(matrix(c(71,2,47,20),nrow=2,byrow=T))
colnames(Tafel) <- c("Not discharge","Discharge")
rownames(Tafel) <- c("Placebo","predinisole")
chisq.test(Tafel)$expected
