#Hand in assignment two statistics with R
#load data
earData <- read.csv("~/Downloads/earData.csv",header=T)
attach(earData)
boxplot(RightHearLoss,LeftHearLoss,names=c("Right loss","Left loss"),
        main = "boxplot of hearing loss of Right and left ear",
        ylab="Hearing loss in (dB)",col="dodgerblue2")

par(mfrow=c(1,2))
hist(RightHearLoss,xlab="Hearing loss in(dB)",
     ylab="Number Observed",col="aquamarine")

hist(LeftHearLoss,xlab="Hearing loss in(dB)",
     ylab="Number Observed",col="cadetblue")

t.test(RightHearLoss,LeftHearLoss)



#Question two
chisq.test(table(Right.Tensa.Ts>0, Left.Tensa.Ts>0), correct=F)

(table(Right.Tensa.Ts))


#association
t.Tensa.At>0))

chisq.test(table(Right.Tensa.Ts>0,Right.Tensa.At>0), correct=F)
chisq.test(table(Left.Tensa.Ts>0,Left.Tensa.At>0), correct=F)

countz <- table(Left.Tensa.Ts>0,Left.Tensa.At>0)
counts <- table(Right.Tensa.Ts>0,Right.Tensa.At>0)
barplot(counts, main="Distribution of scaring and dilution",
        xlab="codition of eardrum", col=c("darkblue","red"),
        legend.text = c("Healthy","Unhealthy")
        , names.arg = c("Healthy","Unhealthy")) 

barplot(countz, main="of right and left ear",
        xlab="codition of eardrum", col=c("darkblue","red"),
        legend.text = c("Healthy","Unhealthy")
        , names.arg = c("Healthy","Unhealthy")) 




table(Right.Tensa.Ts,Right.Tensa.At)
