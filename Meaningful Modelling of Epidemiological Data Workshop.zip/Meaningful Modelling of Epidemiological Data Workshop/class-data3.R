#  #######    Advice on using R   ################
#
#  Most commands are functions with many possible arguments
#  Most are set at default values, but try changing them
#
#  The 'help' in RStudio has a good search facility
#
#  A very concise reference card is here
#  http://cran.r-project.org/doc/contrib/Short-refcard.pdf
#
#  An excellent tutorial site is here
#  http://www.statmethods.net/index.html
#  with a good search facility

class.frame <- read.csv("~/Documents/AIMS/class-data.csv", header=T)
summary(class.frame) # to check variable names, missing data etc
# Note that text variables are read in as 'factors': categorical variables taking values from a list
attach(class.frame)  # so can use names directly

# do the heights have a normal distribution?
# See website http://www.statmethods.net/graphs/density.html
# for instructions on putting curves on top of histograms

# check how many missing values
sum(is.na(handspan)) 
# no missing values
sum(is.na(height))
# 3 missing values

plot(height,handspan, pch=16,col="red")
#  use lm function to fit a line: y = handspan, x = height
fitted=lm(handspan~height) 
abline(fitted, col="blue") # plot fitted regression line (y~x) 
summary(fitted)  # gives coefficients and standard errors etc

install.packages("car")
library(car) # package to do enhanced scatterplots
# fit lines separately for men and women
scatterplot(handspan ~ height | gender, smoother=FALSE,pch=c(16,16),col=c("red","blue"))
