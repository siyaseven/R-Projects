#Assignment one
#loading the data 
Data <- read.csv("/home/siyabonga/Downloads/taiChiData.csv",header=T)
attach(Data)
summary(Data)

hist(FIQ_baseline,main="histogram of Pain scores at baseline",
     ylim=c(0,10),xlab="Baseline pain scores",ylab="Frequency of scores")

hist(FIQ_12W,main="histogram of Pain scores after 12 weeks",
     xlab="FIQ pain scores after 12 weeeks",ylab="Frequency of scores")

hist(FIQ_24W,main="histogram of Pain scores after 24 weeks",
     xlab="FIQ pain scores after 24 weeeks",ylab="Frequency of scores",ylim=c(0,9))

#par(mfrow=c(1,2))
#boxplot
boxplot(FIQ_baseline[treatment=="control"],
        FIQ_12W[treatment=="control"],FIQ_24W[treatment=="control"]
        ,main=" Scores of given treatment(control)",ylab="Pain scores",
        names=c("FIQbase","FIQ12W","FIQ24W"),col="green")

boxplot(FIQ_baseline[treatment=="tai chi"],FIQ_12W[treatment=="tai chi"],
        FIQ_24W[treatment=="tai chi"],main=" Scores of given treatment(tai chi)",
        ylab="Pain scores",
        names=c("FIQbase","FIQ12W","FIQ24W"),col="red")

boxplot(FIQ_baseline,FIQ_12W,FIQ_24W,
        main="Original boxplot(both control&tai chi)",
        names=c("FIQbase","FIQ12W","FIQ24W"),ylab="Severe Scores",col="grey")

boxplot(diffr,diffr2,
        main="Boxplot of the difference between FIQ from baseline",
        names=c("FIQ12W-B","FIQ24W-B"),ylab="differences in scores")

table(treatment,coexists)
table(sex,coexists)
#difference between after week scores and baseline scores
summary(diffr <- FIQ_12W-FIQ_baseline)
summary(diffr2 <- FIQ_24W-FIQ_baseline)

#2.paired t test
t.test(FIQ_baseline[treatment=="control"],FIQ_24W[treatment=="control"],paired=TRUE)
t.test(FIQ_24W,FIQ_baseline,paired=T)
t.test(FIQ_baseline[treatment=="tai chi"],FIQ_24W[treatment=="tai chi"],paired=TRUE)


