 #laod data:
data <- read.csv("/home/siyabonga/Downloads/laegekontakt1991.csv",header=T)
head(data)
names(data)
#Extract and rename variables
head(data)
data <- transform(data, sex=A1,municipality=  A2, income = E31,distance = AFSTDOC,contact = KON1)
names(data)

rm(list=ls())
#=======================================================================


# attempting the Exercise1

#1.Extracting the first data lines 
head(perulung)

#2. Establishing the size of data set
dim(perulung)

#3.Extracting information about id number 36
subset(perulung,id==36)#thus the child is are"pige"

#4.calculating the average of height
mean(perulung$height)

#5. using summary function
summary(perulung)
 
#6. quantintative and categorical variables
#sex and rssymptoms are categorical the rest are quantintative

#=======================================================================
#attempting Exercise two

#1. summary statistics for Height
summary(perulung)
#I get min,1st Qu,mean,median,3rd Qu and max

#2.Histogram for Height
hist(perulung$height)

#3.making a scatter plot of FEV1 against height
pdf(file="myGraphs.pdf")
plot(perulung$fev1,perulung$height)
#plot(perulung$height,perulung$fev1)
dev.off()
#4.Modify the plot such that there are different colours
attach(perulung)
plot(fev1[sex==0],height[sex==0],col='blue')
points(fev1[sex==1],height[sex==1],col='green')

plot(fev1[sex==0],height[sex==0],col=factor(sex))
#5.drawing histograms of fev1 against height
par(mfrow=c(1,2))
hist(fev1[sex==1],labels=T)
hist(fev1[sex==0],labels=T)

#6. which plots ?
plot(sex,fev1)
plot(fev1,sex)
# it a strip chart

#7. tabling sex and respritory problem
prop.table(table(sex,respsymptoms),2)
barplot(prop.table(table(sex,respsymptoms),2))
barplot(table(sex))
table(respsymptoms)
detach(perulung)

#=======================================================================
#Exercise 3.1

#3.1.1 loading the data and calculating BMI
names(sundby)
attach(sundby)
setwd('/home/siyabonga/R/R')
hei<- V76/100
BMI<- (V75/hei^2) 

#3.1.2 calculating box plots
boxplot(BMI~KON,sundby,xlab="sex",ylab="BMI",
        main= "boxplots of men and women",col='blue',
        boxwex = 0.60,names=c('males','females'))

detach(sunby)

#=======================================================================
#exercise 3.2
#1.loading data "pigs.csv"
pigsData <- read.csv("/home/siyabonga/Downloads/pigs.csv")
attach(pigsData)

par(mfrow=c(2,2))
plot(bpSYS[id==101],main = 'blood pressure over time(101)',xlab='time',ylab='blood pressure')
lines(bpSYS[id==101],type='l')

plot(bpSYS[id==103],main = 'blood pressure over time(103)',xlab='time',ylab='blood pressure')
lines(bpSYS[id==103],type='l')
 
plot(bpSYS[id==107],main = 'blood pressure over time(107)',xlab='time',ylab='blood pressure')
lines(bpSYS[id==107],type='l')

plot(bpSYS[id==111],main = 'blood pressure over time(111)',xlab='time',ylab='blood pressure')
lines(bpSYS[id==111],type='l')
detach(pigsData)

#==========================================================================
#Exercise 3.3
#loading US_GDPdata and attaching data
US_GDPdata <- read.csv("/home/siyabonga/Downloads/US_GDP_data.csv")
attach(US_GDPdata)

#1.creating new data year and GDP
Specialdata <- data.frame(Year,GDP)
names(Specialdata)

#2n3n4.ploting GDP
par(mfrow=c(1,2))
plot(log(GDP)[Year>=1929],type='l',log='y')
plot((GDP)[Year>=1929],type='l')
#prefer the one with out log
detach(US_GDPdata)

#=============================================================================
#Exercise 3.4 
#============================================================================

#Normal distribution

mean(sample(1:6,10,replace =TRUE))

hist(replicate(500,mean(sample(1:6,10,replace =TRUE)),simplify="array"))
#==============================================================================
#Confidence interval
#creating a function that calculate confidince interval
MyFunction <- function(x){
  conf <- mean(x) + c(-1,1)*1.96*sd(x)/sqrt(length(x))
  return(conf)
}
MyFunction(rnorm(10))

y <-replicate(10,MyFunction(rnorm(10)))
y
typeof(y)
scan




  