#Python problems done in R as an exercise to familarize myself with R.
#This is done by Siyabonga P mthiyane 
#on the 31st of january 2013
#looking forward to corect mistakes

library("ISwR")

#exercise one
#caliculatiion of an area of trapezium
#x = as.numeric(readline(prompt=''))
myfun <- function(a,b,h){
     C <- 0.5*(a + b)*h
     return(C)
    }
x1= myfun(1, 2, 3)

#exercise two
#the user has to enter the radius,and the program has to calculate lenght of cirmferenceand the area of circle
r = as.numeric(readline(prompt='enter the radius'))
Acircle <- function(z){
  ci = 2*pi*z
  area = pi*z**2
  com <- c(ci, area)
  return (com)

}
Acircle(r)

#exercise three
#The programme convert Fahrenheit to celsius
cel = as.numeric(readline(prompt='enter the celsius in degree'))
fahrenheit <- function(farh){
  Cel = (5.0/9)*(farh-32)
  return(Cel)
}
p = fahrenheit(cel)

#Exercise four
#This program ask the user to input x,y and give result of a given expression
x = as.numeric(readline(prompt='enter the nonnegative value of x'))
y = as.numeric(readline(prompt='enter the nonnegative value of y'))
expresion <- function(x1,y1){
  numeratorQ4 = sqrt(x1**2 + y1)
  denomenatorQ4 = ((1.0/x1)+sin(y1))*2
  return (numeratorQ4/denomenatorQ4)
  
}
expresion(x,y)

#Exercise five
#This is programme calculate bell-shaped Guassian function given all 3 parameters
Gaussian <- function(x,s,m){
    Gau = (1/sqrt(2*pi*s))*exp((-0.5)*((x-m)/s)**2)
    return(Gau)
  
}
Gaussian(1,2,0)

#exercise six
#This program calculate coefficients of a and b in a straight line y = ax + b
point11 = as.numeric(readline(prompt='enter first point (xo)'))
point12 = as.numeric(readline(prompt='enter first point (yo)'))
point21 = as.numeric(readline(prompt='enter first point (x1)'))
point22 = as.numeric(readline(prompt='enter first point (y1)'))
coefficient <- function(x60,y60,x61,y61){
  a6 = (y61-y60)/(x61-x60)
  b6 = y60-a6*x60
  c6 = c(a6, b6)
  return (c6)
  
}
solution = coefficient(point11,point12,point21,point22)

#exercise seven
#THis program ask a user to input a radius and display volume of sphere
Rsph = as.numeric(readline(prompt='enter the radius of sphere'))
volume_sphere <- function(Rs){
  volus = (4/3)*pi*Rs
  return (volus)
}
volume_sphere(Rsph)

#exercise eight
#This programme ask a user to input an integer and check if is divisible by 3,7,11
integ = as.numeric(readline(prompt='enter any integer'))
integer_checker <- function(Iv){
 sol <- NULL
 i <- 3
 #y <- Iv%i
 while (i <= 11){
      if (Iv%%i == 0)
         sol <- c(sol,i)
        i = i+4
 }
 return (sol)
 
}
X8 =integer_checker(integ)

#exercise nine
#This program calculate maximum of three real numbers
r1 = as.numeric(readline(prompt='enter 1st number'))
r2 = as.numeric(readline(prompt='enter 2nd number'))
r3 = as.numeric(readline(prompt='enter 3rd number'))
max(r1:3, r2:3, r3:3)

#exercise ten
#This programme allow a user to input a number and list numbers that divide that number
num = as.numeric(readline(prompt='enter 2nd number'))
Div = NULL
for (x in (2:10)){
  if (num%%x == 0)
  Div <- c(Div,x)
 
}
print(Div)

#exercise eleven
#This programme ask a user to input the sequence of numbers and solve for min,max,aver,SD
sequence <- c(2,4,5,34,5,34,5,4,3,7,8,7,8,5,3,4,4,5,6)
min(sequence)
max(sequence)
ave(sequence)
sd(sequence)  
  
#exercise twelve
#this programme input 3 numbers and sort them as an increasing order
s1 = as.numeric(readline(prompt='enter 1st number'))
s2 = as.numeric(readline(prompt='enter 2nd number'))
s3 = as.numeric(readline(prompt='enter 3rd number'))
In <- NULL
if (s1 < s2 && s1 < s3){
  m1 <- s1
  In <- c(In, s1)
}  
 if(s2< s1 && s2 < s3) {
  
   m2 <- s2
  In <- c(In, s2)
}
 if(s3 < s1 && s3 < s2){
  m3 <- s3
  
  In <- c(In, s3)
}
#else{
 # break
#}

increasing = list(In, m1, m2, m3)

#exercise thirthteen
#This programme convert rands (ZA) to dollars (USD)
rand = as.numeric(readline(prompt='enter the amount of rands you want to convert'))
currency <- function(ZA){
  USD = ZA*0.11179
  return (USD)
  }
usd = currency(rand)

#exercise fourthteen
#This programe ask the user to input a,b,h and check if the parameter of trapezium is correct
a = as.numeric(readline(prompt='enter the minor base'))
b = as.numeric(readline(prompt='enter the senior base'))
h = as.numeric(readline(prompt='enter the height'))
e1= as.numeric(readline(prompt='enter the first angle'))
e2= as.numeric(readline(prompt='enter second degree'))

caltrape <-function(a1,b1,h1,ae,aee){
if (ae != aee){
  sys.exit()#break

  ifelse(ae == aee)
           At = 0.5*(a1+b1)*h1
       
  }
return (At)
}

area_of_trapezium = caltrape(a,b,h,e1,e2)

#exercise fifthteen
#The exercise allow a user to choose if wana calculate for cubic or cylinder
choice = as.numeric(readline(prompt='enter one for cube or two for cylinder'))
if(choice == 1){
    B = as.numeric(readline(prompt='enter the side of the cube'))
    v = B**3
}
    print(v)

ifelse(choice == 2)
    f = as.numeric(readline(prompt='enter the radius of cylinder'))
    g = as.numeric(readline(prompt='enter the height of cylinder'))
    W = pi*f**2*g

    print(W)

#exercise sixthteen
#This programe allow a user to input seconds and convert it in min,days,week,hour,seconds
sec = as.numeric(readline(prompt='enter the amount of second you want to convert'))
mini = sec/60.0
hour = sec/3600.0
day  = sec/86400.0
week = sec/604800
seco = sec 

print(mini,hour,day,week,seco)

#exercise seventhteen
#This programe solve the quadratic equation solution can be real or complex
A = as.numeric(readline(prompt='enter coeficient of x**2'))
B = as.numeric(readline(prompt='enter coeficient of x'))
C = as.numeric(readline(prompt='enter the horizontal intercept'))
I = B**2 - 4*A*C
if(I < 0){
  
  I = (complex(0,1))
  As = as.complex(0,1)
  x1 = (-B+As+sqrt(I))/2*A
  x2 = (-B-As-sqrt(I))/2*A

  ifelse(I > 0)
  x1 = (-B+sqrt(I))/2*A
  x2 = (-B-sqrt(I))/2*A
  }
print(c(x1,x2))

#Exercise Eigthteen
#This programme the number of day of the week than say which day or weekend
x = as.list(readline(prompt='enter any number between 1 and 7'))
if (x == 6 | x == 7){ 
    	 	
  d <- 'weekend' 
  			
  sys.exit()
		  ifelse( x == 1)
  			d <- 'monday'
      ifelse(x ==2)
  			d <- 'Tuesday'
  	  ifelse	(x == 3)
  			d <- 'Wednesday'
  	  ifelse	(x == 4)
        d <- 'Thursday'    
  		ifelse(x == 5)
  			d <- 'Friday'
  print(d)
}

#Exercise ninethteen
#This programe indicates the month number and how many days in that month
y = as.numeric(readline(prompt='enter any number between 1 and 12'))
if(y == 1|3|5|7|8|10|12){
      dayz <- '31 days'
      ifelse(y ==2)
        dayz <- '28 days'
      ifelse (y == 4|6|9|11)
        dayz <- '30 days'
      print(dayz)
}

#Exercise twethtee
#This programme indicates the grade in equavalent text
m = as.numeric(readline(prompt='enter a grade of a student btwn 0 and 10'))
if (m < 5){
    score  <-' Bad'
ifelse (m >= 5 && m < 6)
  score <-'Pass'
ifelse (m >= 6 && m < 7.5)
  score <- 'Good'
ifelse (m >= 7.5 && m < 9)
  score  <-'very_Good'
ifelse (m >= 9 && m <= 10)
  score <- 'Excellent'
else{
  sys.on.exit()
}
}
print(score)

