class.frame <- read.csv("~/Documents/AIMS/class-data.csv", header=T)
summary(class.frame) # to check variable names, missing data etc
# Note that text variables are read in as 'factors': categorical variables taking values from a list
attach(class.frame)  # so can use names directly
tabarmcross = table(armcross) #  create frequency table of values 
pie(tabarmcross,main="Arm on top when crossing")
barplot(tabarmcross,main="Arm on top when crossing")
# turn birthmonth into 'ordered factor' called month
month=factor(birthmonth,levels=c("January","February","March","April","May","June","July","August","September","October","November","December"), labels=c("Ja","Fe","Ma","Ap","My","Jn","Jl","Au","Se","Oc","No","De"),ordered=TRUE)
barplot(table(month))
#
plot(height,footlength)
plotcolours=c(1,2)[Gender]  # chooses 1 or 2 according to Gender
plot(height,footlength,pch=16,col=plotcolours,cex=1.5) # big coloured blobs
stripchart(siblings,main="siblings")  # does not show numbers well
install.packages("lattice")
library("lattice")
histogram(~siblings)
histogram(~siblings|gender) # Need to include ~, to make a 'formula' 
#
# Other questions to ask?
# What plots might we do?
# - Can taller people hold their breath longer?  Does this depend on gender?
# - Do the dice data look like a geometric distribution?
# - Are armcrossing and tongue rolling related?  Does this depend on gender?

